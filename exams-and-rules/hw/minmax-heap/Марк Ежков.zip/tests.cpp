#include <iostream>
#include <cstdlib>
#include <algorithm>
#include <ctime>
#include "MinMaxHeap.h"

using namespace std;

vector<int> generateRandVec(int n) {

	vector<int> v(n, 0);

	for (int i = 0; i < n; i++) {
		v[i] = rand() % 100;
	}

	return v;

}

int main() {

	int size = 1e3;
	int n = 10;

	double aTimeMin = 0.0;
	double aTimeMax = 0.0;

	for (int t = 0; t < n; t++) {

		vector<int> keys = generateRandVec(size);
		
		vector<int> keysMin(size, 0);
		vector<int> keysMax(size, 0);

		MinMaxHeap<int> heapMin(size);
		MinMaxHeap<int> heapMax(size);
		
		heapMin.insert(keys);
		heapMax.insert(keys);

		sort(keys.begin(), keys.end());

		clock_t time = clock();
		double dtime;

		bool correct = true;

		for (int i = 0; i < size; i++) {
			if (keys[i] != heapMin.deleteMin()) {
				correct = false;
				break;
			}
		}

		if (correct) {
			cout << "Test " << t + 1 << " Min correct" << endl;
			dtime = 1.0 * (clock() - time) / CLOCKS_PER_SEC;
			cout << dtime << endl;
			aTimeMin += dtime;
		} else {
			cout << "incorrect" << endl;
			return 0;
		}
		
		time = clock();
		correct = true;

		for (int i = 0; i < size; i++) {
			if (keys[size - i - 1] != heapMax.deleteMax()) {
				correct = false;
				break;
			}
		}

		if (correct) {
			cout << "Test " << t + 1 << " Max correct" << endl;
			dtime = 1.0 * (clock() - time) / CLOCKS_PER_SEC;
			cout << dtime << endl << endl;
			aTimeMax += dtime;
		} else {
			cout << "incorrect" << endl;
			return 0;
		}

	}

	cerr << "Min average:" << aTimeMin / 100.0 << endl;
	cerr << "Max average:" << aTimeMax / 100.0 << endl;

	system("pause");
	return 0;

}