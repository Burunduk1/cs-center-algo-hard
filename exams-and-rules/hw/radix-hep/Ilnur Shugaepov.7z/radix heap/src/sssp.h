#pragma once 
#include <vector>
#include "radix heap.h"
using namespace std;

class edge {
public:
	int u, v, w;
	edge(int u = 0, int v = 0, int w = 0) 
		: u(u), v(v), w(w) {}	
};

typedef vector< vector<edge> > graph;

class SSSP {
public:
	void operator () (graph &g, int s);	

	long long dist(int t) const { return d[t]; }

protected:
	int n;
	vector<long long> d;
};

class Dijkstra_radix : public SSSP {
public:
	void operator () (graph &g, int s, int MAX_WEIGHT);

private:
	int C;
	radix_heap q;
};