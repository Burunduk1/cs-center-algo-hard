#pragma once

#include <iostream>
#include <vector>
#include "list.h"
using namespace std;

typedef list<int> bucket;

class radix_heap {
public:
	radix_heap() {}

	radix_heap(int n, int C);

	bool empty() const;

	bool find(int v);

	void insert(int v, long long x);

	void decrease(int v, long long x);

	int delete_min();

private:

	void reinsert(int j);

	int get_min(int j);

	void _insert(int v, int i);

	inline void remove(int v, int i);

	void init();

	int n, C, B;
	vector<long long> d;

	vector<bucket> b;
	vector<long long> u, size;

	vector< node<int>* > item;
	vector<int> index;

	int non_empty_cnt;
};