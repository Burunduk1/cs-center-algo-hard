#pragma once

template <class T>
class node {
public:
	node(T x = T(), node<T>* nxt = NULL, node<T>* prev = NULL) :
		x(x), nxt(nxt), prev(prev) {}

	T x;
	node<T> *nxt, *prev;	
};

template <class T>
class list {
public:
	list();
	~list();

	list & operator = (const list<T> &L);

	node<T>* push_back(T x);

	void erase(T x);

	void erase(node<T> *&v);
	
	int size() const;

	void _erase(node<T>* &v);

	node<T>* find(T x);

	void destruct();

	int sz;
	node<T>* head, *tail;
};

template<class T>
list<T>::list() { head = tail = NULL, sz = 0; }

template<class T>
list<T>::~list() {
	destruct();
}

template<class T>
list<T> & list<T>::operator=(const list<T> &L) {
	if (this == &L) return *this;

	destruct();	

	node<T>* cur = L.head;
	for(int i = 0; i < L.size(); i++) {
		push_back(cur->x);
		cur = cur->nxt;	
	}

	return *this;
}

template<class T>
node<T>* list<T>::push_back(T x) {
	node<T>* tmp = new node<T>(x);
	if (!sz)
		tail = head = tmp;
	else {
		tmp->prev = tail;
		tail->nxt = tmp;
		tail = tmp; 
	}
	sz++;
	return tmp;
}

template<class T>
void list<T>::erase(T x) {
	node<T>* v = find(x);

	erase(v);
}

template<class T>
void list<T>::erase(node<T> *&v) {
	if (!v) return;

	if(v == head) {			// DANGER
		head = head->nxt;
		delete v;

		//delete head;
		//head = head->nxt;
	}
	else if(v == tail) {
		tail = tail->prev;
		delete v;
		//delete tail;
		//tail = tail->prev;
	}
	else _erase(v);

	sz--;
}

template<class T>
int list<T>::size() const { return sz; }

template<class T>
void list<T>::_erase(node<T>* &v) {
	if(!v) return;

	if (v->prev) v->prev->nxt = v->nxt;
	if (v->nxt)  v->nxt->prev = v->prev;

	delete v;
}

template<class T>
node<T>* list<T>::find(T x) {
	node<T>* v = head;
	bool f = false;
	for(int i = 0; i < sz && !f; i++) {
		if (v->x == x)  f = true;
		else			v = v->nxt;
	}

	return f ? v : NULL;
}

template<class T>
void list<T>::destruct() {
	node<T>* cur = sz ? tail->prev : NULL;
	for(int i = 0; i < sz; i++) {
		delete tail;
		tail = cur;
		if (cur) cur = cur->prev;
	}
	sz = 0;
}