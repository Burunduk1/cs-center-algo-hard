#include <iostream>
#include <fstream>
#include <vector>
#include <set>
#include <ctime>
#include <stdio.h>
#include <stdlib.h>
#define INF 1e10
#include "list.h"
#include"radix heap.h"
#include "sssp.h"
using namespace std;

class Dijkstra : public SSSP {
public:

	void operator () (graph &g, int s) {
		n = g.size();
		d.assign(n, INF);
		d[s] = 0;

		q.insert(make_pair(0, s));
		while(!q.empty()) {
			int v = (*q.begin()).second; 
			q.erase(q.begin());

			for(int i = 0; i < g[v].size(); i++) {
				int to = g[v][i].v;
				long long w = g[v][i].w;

				if (d[v] + w < d[to]) {
					q.erase(make_pair(d[to], to)); 
					d[to] = d[v]+w;
					q.insert(make_pair(d[to], to));
				}
			}
		}
	}

private:

	set< pair<long long, int> > q; 
};

graph g;

Dijkstra_radix sp_radix;
Dijkstra sp;

float t;

void test(int n, int m, int MAX_WEIGHT) {
	g.resize(n);

	for(int i = 0; i < m; i++) {
		int u, v, w;
		u = rand()%n, v = rand()%n, w = rand()%MAX_WEIGHT;
		g[u].push_back(edge(u, v, w));
	}

	cout << n << ' ' << m <<  ' ' << MAX_WEIGHT << '\n';
	t = clock();
	sp(g, 0);
	printf("set:\t\t%f\n", (float)(clock()-t)/CLOCKS_PER_SEC);

	t = clock();
	sp_radix(g, 0, MAX_WEIGHT);
	printf("radix heap:\t%f\n", (float)(clock()-t)/CLOCKS_PER_SEC);

	bool f = true;
	for(int i = 0; i < n; i++) {
		long long r_d = sp_radix.dist(i), d = sp.dist(i);

		f &= r_d == d || (r_d == n*MAX_WEIGHT && d == INF);
	}

	cout << (f ? "YES" : "NO") << '\n';

	g.clear();
}

int main()
{
	for(int n = 1e4; n <= 1e4; n *= 10)
		test(n, 100 * n, 1000);

	printf("%f", (float)clock()/CLOCKS_PER_SEC);

	return 0;
}

