#include "sssp.h"

void Dijkstra_radix::operator () (graph &g, int s, int MAX_WEIGHT) {
	C = MAX_WEIGHT;

	n = g.size();
	d.assign(n, n*C);
	d[s] = 0; 

	q = radix_heap(n, C);
	q.insert(s, 0);

	while(!q.empty()) {
		int v = q.delete_min();

		for(int i = 0; i < g[v].size(); i++) {
			int to = g[v][i].v;
			long long w = g[v][i].w;
			if (d[v]+w < d[to]) {
				d[to] = d[v]+w;

				if (q.find(to))	q.decrease(to, d[v]+w);
				else			q.insert(to, d[v]+w);
			}
		}
	}
}

