#include "radix heap.h"
#include <math.h>

radix_heap::radix_heap(int n, int C) : n(n), C(C) {
	d.resize(n);
	B = ceil( log(C+1)/log(2) )+2;

	b.resize(B+1); u.resize(B+1); size.resize(B+1);
	item.resize(n);
	index.resize(n);

	non_empty_cnt= 0;

	init();
}

bool radix_heap::empty() const { return non_empty_cnt == 0; }

bool radix_heap::find(int v) {
	return item[v] != NULL;
}

void radix_heap::insert(int v, long long x) {
	d[v] = x;
	_insert(v, B);
}

void radix_heap::decrease(int v, long long x) {
	int j = index[v];
	remove(v, j);

	d[v] = x;
	_insert(v, j);	// new d[v] should be less than old one
}

int radix_heap::delete_min() {
	int j = 1, v;
	while(!b[j].size()) j++;

	// v is vertex with smallest tentative cost in bucket j
	v = (j == 1) ? b[1].head->x : get_min(j);  
	remove(v, j);

	if (j == 1) return v;

	u[0] = d[v]-1, u[1] = d[v];
	for(int i = 2; i < j; i++)
		u[i] = min(u[i-1] + size[i], u[j]);

	// remove each vertex from backet j and reinsert it as in decrease	
	reinsert(j);

	return v;
}

void radix_heap::reinsert(int j) {
	int u, size = b[j].size();
	for(int i = 0; i < size; i++) {
		u = b[j].head->x;
		remove(u, j);
		_insert(u, j-1);
	}
}

int radix_heap::get_min(int j) {
	int u = -1;
	node<int> *cur = b[j].head;
	for(int i = 0, v; i < b[j].sz; i++, cur = cur->nxt) {
		v = cur->x;
		if (u == -1 || d[u] > d[v]) {
			u = v;
			if (d[u] == this->u[j-1]+1) break;
		}
	}
	return u; 
}

void radix_heap::_insert(int v, int i) {
	while(u[i] >= d[v]) i--; 
	i = i+1;

	if (!b[i].size()) non_empty_cnt++;

	item[v] = b[i].push_back(v);
	index[v] = i;
}

inline void radix_heap::remove(int v, int i) {
	b[i].erase(item[v]);
	item[v] = NULL;
	if (!b[i].size()) non_empty_cnt--;
}

void radix_heap::init() {
	u[0] = -1;
	u[B] = n*C + 1;

	for(int i = 1, p = 1; i < B; i++) 
		u[i] = p - 1, p *= 2;

	size[0] = 1;
	size[B] = n*C + 1;
	for(int i = 2, p = 1; i < B; i++)
		size[i] = p, p *= 2;
}