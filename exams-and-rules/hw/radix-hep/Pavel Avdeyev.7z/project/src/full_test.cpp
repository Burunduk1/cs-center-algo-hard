#include <chrono>
#include <cstdlib>
#include <cassert>
#include <iostream>
#include <fstream>
#include <limits>
#include <random>
//#include <ctime>

#include "dijkstra.hpp"

#define INF std::numeric_limits<int>::max() / 2
typedef std::vector<std::list<arc_t> > graph_t;

std::vector<std::string> test_names({"input01.txt", "input02.txt", "input03.txt", "input04.txt", 
	"input05.txt", "input06.txt", "input07.txt", "input08.txt", "input09.txt", "input10.txt",
	"input11.txt", "input12.txt"});

std::vector<std::string> answer_names({"answer01.txt", "answer02.txt", "answer03.txt", "answer04.txt", 
	"answer05.txt", "answer06.txt", "answer07.txt", "answer08.txt", "answer09.txt", "answer10.txt",
	"answer11.txt", "answer12.txt"});

graph_t read_list_edges(std::ifstream& in, size_t number_vertices, size_t count_edges) { 
	graph_t graph(number_vertices);

	for (size_t i = 0; i < count_edges; ++i) { 
		size_t s = 0; 
		size_t f = 0; 
		size_t weight = 0;
		in >> s >> f >> weight;

		graph[s].push_back(arc_t(f, weight));
	}

	return graph;
}

void read_answer(std::ifstream& in, std::vector<size_t> & answer, size_t size) { 
	for (size_t i = 0; i < size; ++i) { 
		int temp = 0; 
		in >> temp; 

		if (temp == -1) { 
			answer.push_back(INF);
		} else { 
			answer.push_back(temp);
		}
	}
}

void check_stupid_dijkstra() { 
	size_t right_answer = 0;
	size_t wrong_answer = 0;

	for (size_t i = 0; i < test_names.size(); ++i) { 
		std::string test_file = "tests/" + test_names[i];
		std::string answer_file = "tests/" + answer_names[i];

		size_t number_vertices = 0; 
		size_t number_edges = 0;
		size_t max_cost = 0;
		size_t start = 0;

		std::ifstream in(test_file.c_str());
		in >> number_vertices >> number_edges >> max_cost >> start;
		auto graph = read_list_edges(in, number_vertices, number_edges);
		in.close(); 

		std::vector<size_t> dist(graph.size(), INF);
		stupid_dijkstra(graph, start, dist);

		std::vector<size_t> answer;
		
		std::ifstream ans(answer_file.c_str());
		read_answer(ans, answer, dist.size());
		ans.close();
		

		if (answer == dist) { 
			++right_answer; 
		} else { 
			++wrong_answer;
		}
	}

	std::cout << "Dijkstra with array\n\tPass: " << right_answer << " tests\n\tWA: " << wrong_answer << " tests" <<  std::endl; 
}

void check_binary_heap_dijkstra() { 
	size_t right_answer = 0;
	size_t wrong_answer = 0;

	for (size_t i = 0; i < test_names.size(); ++i) { 
		std::string test_file = "tests/" + test_names[i];
		std::string answer_file = "tests/" + answer_names[i];

		size_t number_vertices = 0; 
		size_t number_edges = 0;
		size_t max_cost = 0;
		size_t start = 0;

		std::ifstream in(test_file.c_str());
		in >> number_vertices >> number_edges >> max_cost >> start;
		auto graph = read_list_edges(in, number_vertices, number_edges);
		in.close(); 

		std::vector<size_t> dist(graph.size(), INF);
		binary_heap_dijkstra(graph, start, dist);

		std::vector<size_t> answer;
		
		std::ifstream ans(answer_file.c_str());
		read_answer(ans, answer, dist.size());
		ans.close();
		

		if (answer == dist) { 
			++right_answer; 
		} else { 
			++wrong_answer;
		}
	}

	std::cout << "Dijkstra with STL priority queue\n\tPass: " << right_answer << " tests\n\tWA: " << wrong_answer << " tests" <<  std::endl; 
}

void check_radix_heap_dijkstra() { 
	size_t right_answer = 0;
	size_t wrong_answer = 0;

	for (size_t i = 0; i < test_names.size(); ++i) { 
		std::string test_file = "tests/" + test_names[i];
		std::string answer_file = "tests/" + answer_names[i];

		size_t number_vertices = 0; 
		size_t number_edges = 0;
		size_t max_cost = 0;
		size_t start = 0;

		std::ifstream in(test_file.c_str());
		in >> number_vertices >> number_edges >> max_cost >> start;
		auto graph = read_list_edges(in, number_vertices, number_edges);
		in.close(); 

		std::vector<size_t> dist(graph.size(), INF);
		radix_heap_dijkstra(graph, max_cost, start, dist);

		std::vector<size_t> answer;
		
		std::ifstream ans(answer_file.c_str());
		read_answer(ans, answer, dist.size());
		ans.close();
		

		if (answer == dist) { 
			++right_answer; 
		} else { 
			++wrong_answer;
		}
	}

	std::cout << "Dijkstra with radix heap\n\tPass: " << right_answer << " tests\n\tWA: " << wrong_answer << " tests" <<  std::endl; 
}

graph_t generate_worm_graph(size_t number_vertices, size_t max_cost) { 
	graph_t graph(number_vertices);
	std::random_device rd;
	std::mt19937 re(rd());
	std::uniform_int_distribution<size_t> ui(1, max_cost);

	for (size_t i = 0; i < number_vertices - 1; ++i) { 
		size_t weight = ui(re); 
		graph[i].push_back(std::make_pair(i + 1, weight));
	}

	return graph;
}

graph_t generate_complete_graph(size_t number_vertices, size_t max_cost) { 
	graph_t graph(number_vertices);
	std::random_device rd;
	std::mt19937 re(rd());
	std::uniform_int_distribution<size_t> ui(1, max_cost);

	for (size_t i = 0; i < number_vertices; ++i) { 
		for (size_t j = 0; j < number_vertices; ++j) { 
			if (i != j) {  
				size_t weight = ui(re);
				graph[i].push_back(std::make_pair(j, weight));
			} 
		}
	} 

	return graph;
}

graph_t generate_random_graph(size_t number_vertices, size_t left_degree, size_t right_degree, size_t max_cost) { 
	std::random_device rd;
	std::mt19937 re(rd());
	graph_t graph(number_vertices);

	std::vector<size_t> vertex_degree(number_vertices, 0);
	std::uniform_int_distribution<size_t> u_degree(left_degree, right_degree);
	for (size_t i = 0; i < number_vertices; ++i) { 
		vertex_degree[i] = u_degree(re);
	}	
	
	//std::cerr << "Finish generate degree " << std::endl;
	
	std::uniform_int_distribution<size_t> u_weight(1, max_cost);
	for (size_t i = 0; i < number_vertices; ++i) { 
		std::uniform_int_distribution<size_t> u_vertex(0, number_vertices - 1);
		for (size_t j = 0; j < vertex_degree[i]; ++j) { 
			size_t vertex = u_vertex(re);
			size_t weight = u_weight(re);
			if (vertex != i) {  
				graph[i].push_back(std::make_pair(vertex, weight));
			} 
		} 
	} 

	return graph;
}

void test_effiency_algorithm_radix_dikkstra(graph_t & graph, size_t max_cost) { 
	size_t start = 0;

	std::vector<size_t> dist(graph.size(), INF);
	auto start_time = std::chrono::high_resolution_clock::now(); 
	radix_heap_dijkstra(graph, max_cost, start, dist);
	auto end_time = std::chrono::high_resolution_clock::now(); 
	std::cout << "Dijkstra with radix heap: " << std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time).count() << " milliseconds" << std::endl;
}

void test_effiency_algorithm_binary_dikkstra(graph_t & graph) { 
	size_t start = 0;

	std::vector<size_t> dist(graph.size(), INF);
	auto start_time = std::chrono::high_resolution_clock::now(); 
	binary_heap_dijkstra(graph, start, dist);
	auto end_time = std::chrono::high_resolution_clock::now(); 
	std::cout << "Dijkstra with STL priority queue: " << std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time).count() << " milliseconds" << std::endl;
} 

void test_effiency_algorithm_array_dikkstra(graph_t & graph) { 
	size_t start = 0;

	std::vector<size_t> dist(graph.size(), INF);
	auto start_time = std::chrono::high_resolution_clock::now(); 
	stupid_dijkstra(graph, start, dist);
	auto end_time = std::chrono::high_resolution_clock::now(); 
	std::cout << "Dijkstra with array: " << std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time).count() << " milliseconds" << std::endl;		
}

int main(int argc, char* argv[]) {
	std::cout << "\t\tVERIFY THAT ALL IS OK" << std::endl;
	check_stupid_dijkstra();
	std::cout << std::endl;
	check_binary_heap_dijkstra();
	std::cout << std::endl;
	check_radix_heap_dijkstra();

	std::cout << std::endl << "\t\tTEST EFFICIENTY ALGORITHM" << std::endl;
	std::cout << std::endl;
	std::cout << "\tTest on \"worm\" graph with 10^4 verteces" << std::endl; 
	graph_t graph = generate_worm_graph(10000, 500);
	test_effiency_algorithm_radix_dikkstra(graph, 500);
	test_effiency_algorithm_binary_dikkstra(graph);
	//test_effiency_algorithm_array_dikkstra(graph);
	std::cout << std::endl;

	std::cout << "\tTest on \"worm\" graph with 10^5 verteces" << std::endl; 
	graph = generate_worm_graph(100000, 500);
	test_effiency_algorithm_radix_dikkstra(graph, 500);
	test_effiency_algorithm_binary_dikkstra(graph);
	//test_effiency_algorithm_array_dikkstra(graph);
	std::cout << std::endl;

	std::cout << "\tTest on \"worm\" graph with 10^6 verteces" << std::endl; 
	graph = generate_worm_graph(1000000, 500);
	test_effiency_algorithm_radix_dikkstra(graph, 500);
	test_effiency_algorithm_binary_dikkstra(graph);
	std::cout << std::endl;

	std::cout << "\tTest on complete graph with 10 verteces" << std::endl; 
	graph = generate_complete_graph(10, 500);
	test_effiency_algorithm_radix_dikkstra(graph, 500);
	test_effiency_algorithm_binary_dikkstra(graph);
	//test_effiency_algorithm_array_dikkstra(graph);
	std::cout << std::endl;

	std::cout << "\tTest on complete graph with 10^2 verteces" << std::endl; 
	graph = generate_complete_graph(100, 500);
	test_effiency_algorithm_radix_dikkstra(graph, 500);
	test_effiency_algorithm_binary_dikkstra(graph);
	//test_effiency_algorithm_array_dikkstra(graph);
	std::cout << std::endl;

	std::cout << "\tTest on complete graph with 10^3 verteces" << std::endl; 
	graph = generate_complete_graph(1000, 500);
	test_effiency_algorithm_radix_dikkstra(graph, 500);
	test_effiency_algorithm_binary_dikkstra(graph);
	//test_effiency_algorithm_array_dikkstra(graph);
	std::cout << std::endl;

	std::cout << "\tTest on random graph with 10^3 verteces" << std::endl; 
	graph = generate_random_graph(1000, 50, 90, 500);
	test_effiency_algorithm_radix_dikkstra(graph, 500);
	test_effiency_algorithm_binary_dikkstra(graph);
	//test_effiency_algorithm_array_dikkstra(graph);
	std::cout << std::endl;

	std::cout << "\tTest on random graph with 10^3 verteces" << std::endl; 
	graph = generate_random_graph(1000, 80, 110, 500);
	test_effiency_algorithm_radix_dikkstra(graph, 500);
	test_effiency_algorithm_binary_dikkstra(graph);
	//test_effiency_algorithm_array_dikkstra(graph);
	std::cout << std::endl;

	std::cout << "\tTest on random graph with 10^4 verteces" << std::endl; 
	graph = generate_random_graph(10000, 80, 110, 500);
	test_effiency_algorithm_radix_dikkstra(graph, 500);
	test_effiency_algorithm_binary_dikkstra(graph);
	//test_effiency_algorithm_array_dikkstra(graph);
	std::cout << std::endl;

	std::cout << "\tTest on random graph with 10^5 verteces" << std::endl; 
	graph = generate_random_graph(100000, 80, 110, 500);
	test_effiency_algorithm_radix_dikkstra(graph, 500);
	test_effiency_algorithm_binary_dikkstra(graph);
	//test_effiency_algorithm_array_dikkstra(graph);
	std::cout << std::endl;

	return 0;
} 