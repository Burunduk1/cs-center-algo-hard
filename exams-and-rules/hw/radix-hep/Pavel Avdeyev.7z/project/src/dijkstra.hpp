#ifndef DIJKSTRA_HPP
#define DIJKSTRA_HPP

#include <queue>

#include "RadixHeap.hpp"

typedef std::pair<size_t, size_t> arc_t;

class Comparator { 
public:
	bool operator()(arc_t const & f, arc_t const &s) {
		return f.first < s.first; 
	}
};

typedef std::priority_queue<arc_t, std::vector<arc_t>, Comparator> binary_heap_t;

template<class graph_t>
void stupid_dijkstra(graph_t const & graph, size_t start, std::vector<size_t>& dist) {
	std::vector<bool> mark(dist.size(), false); 
	dist[start] = 0;

	auto find_min = [&]() -> size_t {
		size_t min_ind = 0; 
		for (; min_ind < dist.size() && mark[min_ind]; ++min_ind) 
			;
		
		for (size_t i = 1; i < dist.size(); ++i)  {   
			if (dist[min_ind] > dist[i] && !mark[i]) { 
				min_ind = i;
			}
		}
		return min_ind;
	};	 

	auto is_all_process = [&]() -> bool { 
		for (size_t i = 0; i < mark.size(); ++i) { 
			if (!mark[i]) return false;
		}
		return true;
	};

	while (!is_all_process()) { 
		size_t ind = find_min();

		for (auto const & arc : graph[ind]) { 
			if (dist[arc.first] > dist[ind] + arc.second) { 	
				dist[arc.first] =	dist[ind] + arc.second;
			} 
		} 

		mark[ind] = true;
	}
}

template<class graph_t>
void binary_heap_dijkstra(graph_t const & graph, size_t start, std::vector<size_t>& dist) { 
	binary_heap_t heap;
	heap.push(std::make_pair(0, start));

	dist[start] = 0;
	while (!heap.empty()) { 
		auto item = heap.top();
		heap.pop();

		for (auto const & arc : graph[item.second]) { 
			if (dist[arc.first] > dist[item.second] + arc.second) { 	
				dist[arc.first] =	dist[item.second] + arc.second;
				heap.push(std::make_pair(dist[item.second] + arc.second, arc.first));				
			}
		} 
	}
} 

template<class graph_t>
void radix_heap_dijkstra(graph_t const & graph, size_t max_cost, size_t start, std::vector<size_t>& dist) {	
	RadixHeap<size_t> heap(max_cost);
	heap.add(std::make_pair(0, start));
	
	dist[start] = 0;
	while (!heap.empty()) { 
		auto item = heap.extract_min();
		
		for (auto const & arc : graph[item.second]) { 
			if (dist[arc.first] > dist[item.second] + arc.second) { 	
				if (heap.is_element(std::make_pair(dist[arc.first], arc.first))) { 
					heap.decreaseKey(std::make_pair(dist[arc.first], arc.first), dist[item.second] + arc.second);
				} else { 
					heap.add(std::make_pair(dist[item.second] + arc.second, arc.first));
				} 
				dist[arc.first] =	dist[item.second] + arc.second;
			}
		} 
	}
}

#endif 