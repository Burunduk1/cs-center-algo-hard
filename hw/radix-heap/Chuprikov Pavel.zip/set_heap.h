#include <set>
#include <stack>
#include <vector>

using namespace std;

template<class T>
class set_heap_t {
public:
    typedef size_t entry_id_t;

public:
    set_heap_t() : storage_{}, free_ids_{}, heap_{} {
    }

    entry_id_t push(size_t key, T const& value) {
        auto entry_id = alloc_entry();
        storage_[entry_id] = make_pair(key, value);
        heap_.insert(make_pair(key, entry_id));
        return entry_id;
    }

    pair<size_t, T> pop() {
        auto const res_id = heap_.begin()->second;
        heap_.erase(heap_.begin());
        auto const res = storage_[res_id];
        free_entry(res_id);
        return res;
    }

    void decrease_key(entry_id_t id, size_t new_key) {
        heap_.erase(make_pair(storage_[id].first, id));
        storage_[id].first = new_key;
        heap_.insert(make_pair(new_key, id));
    }

    bool empty() const {
        return heap_.empty();
    }

    size_t key(entry_id_t id) const {
        return storage_[id].first;
    }

    T const& value(entry_id_t id) const {
        return storage_[id].second;
    }

private:
    entry_id_t alloc_entry() {
        if (free_ids_.empty()) {
            storage_.push_back(pair<size_t, T>{});
            free_ids_.push(storage_.size() - 1);
        }
        auto res = free_ids_.top();
        free_ids_.pop();
        return res;
    }

    void free_entry(entry_id_t id) {
        free_ids_.push(id);
    }

private:
    vector<pair<size_t, T>> storage_;
    stack<size_t> free_ids_;
    set<pair<size_t, size_t>> heap_;
};
