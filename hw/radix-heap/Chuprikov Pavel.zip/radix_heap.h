#include <vector>
#include <cassert>
#include <list>
#include <limits>
#include <memory>
#include <stdexcept>

using namespace std;

template<class T>
class radix_heap_t {
private:
    struct entry_t;

public:
    typedef entry_t const * entry_id_t;
public:
    radix_heap_t(size_t max_diff = 1000);     

    radix_heap_t(radix_heap_t const&) = delete;
    radix_heap_t& operator=(radix_heap_t const&) = delete;

    entry_id_t push(size_t key, T const& value);
    pair<size_t, T> pop();
    void decrease_key(entry_id_t id, size_t new_key);
    
    bool empty() const { 
        return size_ == 0; 
    }

    size_t key(entry_id_t id) const {
        return id->key;
    }
    
    T const& value(entry_id_t id) const {
        return id->value;
    }

private:
    entry_id_t moveto(unique_ptr<entry_t> ptr, size_t initial_bucket_idx);

private:
    vector<list<unique_ptr<entry_t>>> buckets_;
    vector<size_t> l_;
    vector<size_t> r_;
    size_t size_;
};

template<class T>
radix_heap_t<T>::radix_heap_t(size_t max_diff)
    : buckets_{}, l_{}, r_{}, size_{} {
    auto num_buckets = 0u;
    while ((1u << num_buckets) <= max_diff)
        num_buckets++;

    buckets_.resize(num_buckets + 2);
    r_.resize(num_buckets + 2);
    l_.resize(num_buckets + 2);
    r_.back() = numeric_limits<size_t>::max();
}

template<class T>
struct radix_heap_t<T>::entry_t {
    entry_t(size_t key, T const& value) 
        : key(key), value(value), bucket_it{}, bucket_idx{}
    {}

    size_t key;
    T value;

    typename list<unique_ptr<entry_t>>::iterator bucket_it;
    size_t bucket_idx;
};

template<class T>
typename radix_heap_t<T>::entry_id_t radix_heap_t<T>::push(size_t key, T const& value) {
    size_++;
    return moveto(unique_ptr<entry_t>(new entry_t(key, value)), buckets_.size() - 1);
}

template<class T>
pair<size_t, T> radix_heap_t<T>::pop() {
    for (auto i = 0; i < (int)buckets_.size(); i++) {
        if (!buckets_[i].empty()) {
            auto best_id = buckets_[i].front().get();

            if (i > 0) {
                for (auto j = 0; j < i; j++) {
                    if (j == 0) {
                        l_[j] = l_[i];
                        r_[j] = l_[j] + 1;
                    } else {
                        l_[j] = r_[j - 1];
                        r_[j] = l_[j] + (1 << (j - 1));
                    }
                }
                l_[i] = r_[i - 1];
                if (i != (int)buckets_.size() - 1)
                    r_[i] = l_[i];
                
                for (auto& entry : buckets_[i]) {
                    if (entry->key < best_id->key)
                        best_id = entry.get();
                    moveto(move(entry), i - 1);
                }
                buckets_[i].clear();
            }

            auto const result = make_pair(best_id->key, best_id->value);
            buckets_[best_id->bucket_idx].erase(best_id->bucket_it);
            size_--;
            return result;
        }
    }
    throw std::out_of_range("Pop from an empty queue.");
}

template<class T>
typename radix_heap_t<T>::entry_id_t radix_heap_t<T>::moveto(unique_ptr<entry_t> entry, 
        size_t initial_bucket_idx) {
    assert(entry);
    for (auto j = (int)initial_bucket_idx; j >= 0; j--) {
        if (l_[j] <= entry->key && entry->key < r_[j]) {
            buckets_[j].emplace_front(move(entry));
            buckets_[j].front()->bucket_idx = j;
            buckets_[j].front()->bucket_it = buckets_[j].begin();
            return buckets_[j].front().get();
        }
    }
    assert(false);
}

template<class T>
void radix_heap_t<T>::decrease_key(entry_id_t id, size_t new_key) {
    if (new_key > id->key)
        throw std::invalid_argument("New key is greater than old.");

    (*id->bucket_it)->key = new_key;
    if (id->key < l_[id->bucket_idx]) {
        auto ptr = move(*id->bucket_it);
        buckets_[id->bucket_idx].erase(id->bucket_it);
        moveto(move(ptr), id->bucket_idx - 1);
    }
}    
