#!/bin/bash

set -e -o pipefail

TIMEFORMAT="%Rs"

number_of_tests=5

if [ "$1" != "--pandoc" ]; then
    separator="-s \"|\""
fi

function testit {
    dijkstra_time="$(time (./dijkstra < input > dijkstra.output) 2>&1)"
    naive_time="$(time (./naive_dijkstra < input > naive_dijkstra.output) 2>&1)"
    if ! diff dijkstra.output naive_dijkstra.output > /dev/null; then
        echo -e "\033[0;31mWrong answer!\033[0m" >&2
        exit 1
    fi
    echo "|$1|${dijkstra_time}|${naive_time}|"
}

echo "Number of test instances per run: ${number_of_tests}"
echo ""
m=100000
c=10000
echo "Testing dependency on number of vertices (m = $m, c = $c):"
echo ""
{ 
    echo "|vertices|radix|set|"
    echo "|--:|--:|--:|"
    for ((i=100000; i<=1000000; i=$i+100000)); do
        ./gen_test sparse ${number_of_tests} $i $m $c > input
        testit $i
    done 
} | column -t ${separator}

n=100000
c=10000
echo ""
echo "Testing dependency on number of edges (n = $n, c = $c):"
echo ""
{
    echo "|edges|radix|set|"
    echo "|--:|--:|--:|"
    for ((i=100000; i<=1000000; i=$i+100000)); do
        ./gen_test sparse ${number_of_tests} $n $i $c > input
        testit $i
    done
} | column -t ${separator}

n=100000
c=10
echo ""
echo "Testing dependency on number of edges (n = $n, c = $c):"
echo ""
{
    echo "|edges|radix|set|"
    echo "|--:|--:|--:|"
    for ((i=100000; i<=1000000; i=$i+100000)); do
        ./gen_test sparse ${number_of_tests} $n $i $c > input
        testit $i
    done
} | column -t ${separator}


#n=1000
#c=10
#p=0.2
#echo ""
#echo "Testing dependency on number of edges (n = $n, c = $c, p = $p):"
#echo ""
#{
#    echo "|edges|radix|set|"
#    echo "|--:|--:|--:|"
#    for ((i=1; i<=10; i=$i+1)); do
#        ./gen_test dense ${number_of_tests} $n $p $c > input
#        testit $i
#    done
#} | column -t ${separator}

n=10000
m=1000000
echo ""
echo "Testing dependency on the value (n = $n, m = $m):"
echo ""
{
    echo "|value|radix|set|"
    echo "|--:|--:|--:|"
    for ((i=10; i<=10000000; i=$i*10)); do
        ./gen_test sparse ${number_of_tests} $n $m $i > input
        testit $i
    done
} | column -t ${separator}


rm input dijkstra.output naive_dijkstra.output

