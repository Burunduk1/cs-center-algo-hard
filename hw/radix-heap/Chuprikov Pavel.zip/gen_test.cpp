#include <cstdlib>
#include <set>
#include <iostream>
#include <queue>
#include <cassert>

using namespace std;

struct edge_t { int v; size_t w; };

int main(int, char const* argv[]) {
    assert(string(argv[1]) == "dense" || string(argv[1]) == "sparse");
    auto const is_dense = string(argv[1]) == "dense";
    auto const num_tests = stoi(argv[2]);
    auto const num_vertices = stoi(argv[3]);
    auto const max_value = stoi(argv[5]);

    ios_base::sync_with_stdio(false);
    cout << num_tests << '\n';

    srand(12);
    for (int test = 0; test < num_tests; test++) {

        auto graph = vector<vector<edge_t>>(num_vertices);
        auto num_edges = 0;
        if (is_dense) {
            auto p = stod(argv[4]);
            for (auto u = 0; u < num_vertices; u++) {
                for (auto v = 0; v < num_vertices; v++) {
                    if (rand() <= RAND_MAX * p) {
                        size_t const c = rand() % max_value;
                        graph[u].push_back(edge_t{v, c});
                        num_edges++;
                    }
                }
            }
        } else {
            num_edges = stoi(argv[4]);
            for (auto i = 0; i < num_edges; i++) {
                auto const u = rand() % num_vertices;
                auto const v = rand() % num_vertices;
                size_t const c = rand() % max_value;
                graph[u].push_back(edge_t{v, c});
            }
        }
        cout << num_vertices << ' ' << num_edges << '\n';

        for (auto u = 0; u < (int)graph.size(); u++) {
            for (auto e : graph[u]) {
                cout << (u + 1) << ' ' << (e.v + 1) << ' ' << e.w << '\n';
            }
        }
        auto const s = rand() % num_vertices;

        auto reachable = vector<int>{};
        auto visited  = vector<bool>(num_vertices);
        auto bfsq = queue<int>{};

        bfsq.push(s); 
        reachable.push_back(s);
        visited[s] = true;

        while (!bfsq.empty()) {
            auto const u = bfsq.front(); bfsq.pop();
            for (auto const e  : graph[u]) {
                if (!visited[e.v]) {
                    reachable.push_back(e.v);
                    bfsq.push(e.v);
                    visited[e.v] = true;
                }
            }
        }

        auto const t = reachable[rand() % reachable.size()];
        cout << (s + 1) << ' ' << (t + 1) << '\n';
    }
}
