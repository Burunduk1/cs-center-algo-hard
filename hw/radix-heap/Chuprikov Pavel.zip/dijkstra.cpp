#include <vector>
#include <limits>
#include <iostream>

#ifdef USE_RADIX_HEAP
#include "radix_heap.h"
#else
#include "set_heap.h"
#endif

using namespace std;

struct edge_t { int v; size_t w; };
typedef vector<vector<edge_t>> graph_t;

vector<size_t> dijkstra(graph_t const& g, int s) {

#ifdef USE_RADIX_HEAP
    size_t max_weight = 0;
    for (auto& u : g) {
        for (auto& e : u) {
            max_weight = max(max_weight, e.w);
        }
    }

    radix_heap_t<int> q(max_weight);
    typedef radix_heap_t<int> heap_t;
#else
    set_heap_t<int> q;
    typedef set_heap_t<int> heap_t;
#endif

    auto idx2id = vector<heap_t::entry_id_t>(g.size());
    auto color  = vector<int>(g.size(), 0);
    auto result = vector<size_t>(g.size(), numeric_limits<size_t>::max());

    idx2id[s] = q.push(0, s);
    color[s]++;

    while (!q.empty()) {
        auto ud = q.pop();
        color[ud.second]++;
        result[ud.second] = ud.first;

        for (auto e : g[ud.second]) {
            auto const new_dist = ud.first + e.w;
            if (color[e.v] == 0) {
                idx2id[e.v] = q.push(new_dist, e.v);
                color[e.v]++;
            } else if (color[e.v] == 1 && q.key(idx2id[e.v]) > new_dist) {
                 q.decrease_key(idx2id[e.v], new_dist);
            }
        }
    }

    return result;
}

int main() {
    ios_base::sync_with_stdio(false);

    int num_tests; 
    cin >> num_tests;

    for (auto i = 0; i < num_tests; i++) {
        int n, m;
        cin >> n >> m;

        auto g = graph_t(n);
        for (auto i = 0; i < m; i++) {
            int u, v; size_t w;
            cin >> u >> v >> w;
            g[u - 1].push_back(edge_t{v - 1, w});
        }

        int s, t;
        cin >> s >> t;

        auto answ = dijkstra(g, s - 1)[t - 1];
        if (answ == numeric_limits<size_t>::max())
            cout << "NO\n";
        else
            cout << answ << '\n';
    }
}
