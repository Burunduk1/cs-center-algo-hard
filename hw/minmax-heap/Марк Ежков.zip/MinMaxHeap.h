#pragma once

#include <vector>
#include <algorithm>
#include <utility>
#include <cmath>
#include <iostream>
#include <string>
#include <array>

using namespace std;

template<class number>
class MinMaxHeap {

private:

	number* data;
	int last;

	int left(int i) {

		int l = 2 * i;

		if (i == 0 || l > last) {
			return 0;
		}

		return l;

	}

	int right(int i) {

		int r = 2 * i + 1;

		if (i == 0 || r > last) {
			return 0;
		}

		return r;

	}

	int parent(int i) {
		return i / 2;
	}

	int grandParent(int i) {
		return i / 4;
	}

	vector<int> family(int i) {

		vector<int> f;

		if (i == 0 || i > last) {
			return f;
		}

		int f0[] = {
			2 * i, 2 * i + 1, 4 * i, 4 * i + 1, 4 * i + 2, 4 * i + 3
		};

		for (int j = 0; j < 6; j++) {
			if (f0[j] <= last) {
				f.push_back(f0[j]);
			}
		}

		return f;

	}

	int level(int i) {

		int lev = 0;

		while (i >>= 1) {
			lev++;
		}

		return lev;

	}

	void trickleDown(int i, bool min) {

		vector<int> f = family(i);
		vector<number> v;

		for (int j = 0; j < f.size(); j++) {
			v.push_back(data[f[j]]);
		}

		if (f.size() > 0) {

			int m;

			if (min) {
				m = f[min_element(v.begin(), v.end()) - v.begin()];
			}
			else {
				m = f[max_element(v.begin(), v.end()) - v.begin()];
			}

			if (grandParent(m) == i) {

				if (data[m] < data[i] && min == true ||
					data[m] > data[i] && min == false) {

					swap(data[i], data[m]);

					if (data[m] > data[parent(m)] && min == true ||
						data[m] < data[parent(m)] && min == false) {
						swap(data[m], data[parent(m)]);
					}

					trickleDown(m, min);

				}

			}
			else {
				if (data[m] < data[i] && min == true ||
					data[m] > data[i] && min == false) {
					swap(data[i], data[m]);
				}
			}		}	}

public:

	MinMaxHeap(int size) {
		data = new number[size] - 1;
		last = 0;
	}

	~MinMaxHeap() {
		delete[] (data + 1);
		data = NULL;
	}

	int size() {
		return last;
	}

	void add(number key) {
		last++;
		data[last] = key;
	}

	void insert(number key) {

		add(key);

		if (last == 1) {
			return;
		}

		int i = last;

		bool isMin = (level(i) % 2 == 0);
		bool checkMin = (key < data[parent(i)]);

		int next;
		if (isMin == checkMin) {
			next = grandParent(i);
		} else {
			next = parent(i);
		}

		while (next > 0) {

			if (checkMin && key < data[next] || !checkMin && key > data[next]) {
				swap(data[i], data[next]);
			} else {
				break;
			}

			i = next;
			next = grandParent(i);

		}

	}

	void insert(vector<number>& keys) {
		for (int i = 0; i < keys.size(); i++) {
			insert(keys[i]);
		}
	}

/*	void print() {

		cout << endl;

		int lev = 0;

		while (lev <= level(last)) {

			for (int i = pow(2, lev); i < pow(2, lev + 1); i++) {
				if (data[i] >= 0) {
					cout << data[i] << " ";
				}
			}

			cout << endl;
			lev++;

		}

		cout << endl;

	}*/

	number deleteMin() {

		number min = data[1];

		data[1] = 0;
		swap(data[1], data[last]);
		last--;

		trickleDown(1, true);

		return min;

	}

	number deleteMax() {

		number max;

		if (last == 0) {
			max = 0;
		} else if (last == 1 || last == 2) {

			max = data[last];

			data[last] = 0;
			last--;

		} else {

			int m;

			if (data[2] > data[3]) {
				m = 2;
			} else {
				m = 3;
			}

			max = data[m];

			data[m] = 0;
			swap(data[m], data[last]);
			last--;

			trickleDown(m, false);

		}

		return max;

	}

};