#include <iostream>
#include <cstdlib>
#include <algorithm>
#include <ctime>
#include "MinMaxHeap.h"

using namespace std;

vector<int> generateRandVec(int n) {

	vector<int> v(n, 0);

	for (int i = 0; i < n; i++) {
		v[i] = rand();
	}

	return v;

}

int main() {

	int size = 1e2;
	int n = 10;

	double aTime = 0.0;

	for (int t = 0; t < n; t++) {

		vector<int> keys = generateRandVec(size);

		MinMaxHeap<int> heap(size);	
		heap.insert(keys);

		sort(keys.begin(), keys.end());

		clock_t time = clock();
		double dtime;

		bool correct = true;

		for (int i = 0; i < size; i++) {

			if (i % 2 == 0) {

				if (keys[i/2] != heap.deleteMin()) {
					correct = false;
					break;
				}

			} else {

				if (keys[size - i/2 - 1] != heap.deleteMax()) {
					correct = false;
					break;
				}

			}

		}

		if (correct) {
			cout << "Test " << t + 1 << " correct" << endl;
			dtime = (1.0 * (clock() - time)) / CLOCKS_PER_SEC;
			cout << dtime << endl;
			aTime += dtime;
		} else {
			cout << "incorrect" << endl;
		}

	}

	cerr << "Min average:" << aTime / n << endl;

	system("pause");
	return 0;

}