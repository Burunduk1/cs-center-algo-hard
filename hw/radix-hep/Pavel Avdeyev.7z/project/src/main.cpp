#include <cassert>
#include <iostream>
#include <fstream>
#include <limits>

#include "dijkstra.hpp"

#define INF std::numeric_limits<int>::max() / 2

typedef std::vector<std::list<arc_t> > graph_t;

graph_t read_list_edges(std::ifstream& in, size_t number_vertices, size_t count_edges) { 
	graph_t graph(number_vertices);

	for (size_t i = 0; i < count_edges; ++i) { 
		size_t s = 0; 
		size_t f = 0; 
		size_t weight = 0;
		in >> s >> f >> weight;

		graph[s].push_back(arc_t(f, weight));
	}

	return graph;
}

int main(int argc, char* argv[]) {
	if (argc != 3) {
		std::cerr << "Usage: ./task <graph.in> <graph.out>" << std::endl; 
		return 1;
	} 

	std::ifstream in(argv[1]);
	size_t number_vertices = 0;
	size_t count_edges = 0;
	size_t max_cost = 0; 
	size_t start = 0;
	
	in >> number_vertices >> count_edges >> max_cost >> start;
	auto graph = read_list_edges(in, number_vertices, count_edges);
	in.close(); 

	std::vector<size_t> dist(graph.size(), INF);
	radix_heap_dijkstra(graph, max_cost, start, dist);
	
	std::ofstream out(argv[2]);
	for (size_t i = 0; i < dist.size(); ++i) {
		if (dist[i] == INF) { 
			out << "-1 ";
		} else { 
			out << dist[i] << " ";
		} 
	}
	out << std::endl;
	out.close();
	return 0;
}