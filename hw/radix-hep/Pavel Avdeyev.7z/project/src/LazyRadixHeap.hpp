#ifndef LAZYRADIXHEAP_HPP
#define LAZYRADIXHEAP_HPP

#include <cmath>
#include <cassert>

#include <list>
#include <tuple>
#include <vector>

#include <algorithm>

template<class elem_t>
struct LazyRadixHeap { 
	typedef std::pair<int64_t, elem_t> item_t;
	typedef std::tuple<int64_t, elem_t, bool> node_t;
	typedef std::list<node_t> bucket_t;
	typedef typename bucket_t::iterator pointer_t; 

	LazyRadixHeap(size_t max_cost, size_t number_vertices)
	: m_size(0) 
	, last_deleted(0) 
	, buckets(static_cast<size_t>(ceil(log2(max_cost + 1))))
	, all_elements(number_vertices, buckets[0].end())
	, summary(std::numeric_limits<size_t>::max())
	, count_add(0)
	, count_decrease(0)
	{
	}

	LazyRadixHeap(size_t max_cost, size_t number_vertices, size_t number_edges)
	: m_size(0) 
	, last_deleted(0) 
	, buckets(static_cast<size_t>(ceil(log2(max_cost + 1))))
	, all_elements(number_vertices, buckets[0].end())
	, summary(number_vertices * static_cast<size_t>(ceil(log2(max_cost + 1))) + number_edges)
	, count_add(0)
	, count_decrease(0)
	{ 
	}

	inline size_t size() const { // O(1)
		return m_size;
	}

	inline bool empty() const { // O(1)
		return (m_size == 0);
	}

	inline void add(item_t const & elem) { // O(1)
		//std::cerr << "add " << std::endl;
		++count_add; 
		assert((count_add + count_decrease) <= summary);
		add_elem(elem.first, elem.second);
		++m_size;
	}

	inline void decreaseKey(int64_t new_prior, item_t const & elem) { // O(1)
		//std::cerr << "decreaseKey " << std::endl;
		++count_decrease; 
		assert((count_add + count_decrease) <= summary);
		assert(m_size != 0);		
		pointer_t iter = all_elements[elem.second];
		assert(iter != buckets[0].end());
		std::get<2>(*iter) = true;
		add_elem(new_prior, elem.second);
	}

	item_t extract_min() { // O(logC) - amor
		//std::cerr << "extract min " << std::endl;
		--m_size;	
		if (!buckets[0].empty()) { 
			node_t deleted = buckets[0].back();
			assert(std::get<2>(deleted) != true);
			last_deleted = std::get<0>(deleted);
			buckets[0].pop_back();
			return item_t(std::get<0>(deleted), std::get<1>(deleted));
		} 

		size_t ind = 1;  
		for (; ind < buckets.size() && buckets[ind].empty(); ++ind)
			;

		pointer_t iter = std::min_element(buckets[ind].begin(), buckets[ind].end(), [](node_t const & f, node_t const & s) {
			return std::get<0>(f) < std::get<0>(s);
		});
		
		item_t deleted = item_t(std::get<0>(*iter), std::get<1>(*iter));
		std::get<2>(*iter) = true;
		last_deleted = deleted.first;

		//move all elements from bucket[ind]
		for (auto it = buckets[ind].begin(); it != buckets[ind].end();) { 
			if (std::get<2>(*it) == true) { 
				buckets[ind].erase(it++);
			} else { 
				size_t new_ind = get_index_element(std::get<0>(*it));
				if (new_ind != buckets.size() - 1) {
					buckets[new_ind].push_back(*it);
					all_elements[std::get<1>(*it)] = (--buckets[new_ind].end());
					buckets[ind].erase(it++);
				} else { 
					all_elements[std::get<1>(*it)] = it;
					++it;
				}
			}
		} 
		return deleted;
	}

	void print_buckets() { 
		for (size_t i = 0; i < buckets.size(); ++i) { 
			std::clog << i << ": "; 
			for (auto it = buckets[i].begin(); it != buckets[i].end(); ++it) { 
				std::clog << "(" << std::get<0>(*it) << ", " << std::get<1>(*it) << ") "; 
			}  
			std::clog << std::endl;
		} 
	} 
	
private: 
	inline void add_elem(int64_t prior, elem_t elem) {
		size_t ind = get_index_element(prior); 
		buckets[ind].push_back(std::make_tuple(prior, elem, false));		
		all_elements[elem] = (--buckets[ind].end());
	}

	inline size_t get_index_element(int64_t prior) { 
		size_t ind = higest_bit(prior ^ last_deleted) + 1;
		if (ind > buckets.size() - 1) { 
			ind = buckets.size() - 1;
		}
		return ind;
	}

	inline size_t higest_bit(int64_t x) { 
		if (x == 0) { 
			return -1;
		} else {
			size_t r = 0;
			while (x >>= 1) { 
				++r;
			}
			return r;
		}
	}

private:
	size_t m_size; 
	int64_t last_deleted;
	std::vector<bucket_t> buckets;
	std::vector<pointer_t> all_elements;

	//Test variables
	size_t summary; 
	size_t count_add; 
	size_t count_decrease; 
};


#endif
