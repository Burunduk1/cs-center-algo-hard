#ifndef DIJKSTRA_HPP
#define DIJKSTRA_HPP

#include <queue>

#include "RadixHeap.hpp"
#include "LazyRadixHeap.hpp"

#define INF (std::numeric_limits<int64_t>::max())
typedef std::pair<int64_t, size_t> item_t;

struct Comparator { 
	bool operator()(item_t const & f, item_t const &s) {
		return f.first > s.first; 
	}
};

typedef std::priority_queue<item_t, std::vector<item_t>, Comparator> binary_heap_t;

template<class graph_t>
void stupid_dijkstra(graph_t const & graph, size_t max_cost, size_t start, std::vector<int64_t>& dist, size_t number_edges = INF) {
	std::vector<bool> mark(dist.size(), false); 
	dist[start] = 0;

	auto find_min = [&]() -> size_t {
		size_t min_ind = 0; 
		for (; min_ind < dist.size() && mark[min_ind]; ++min_ind) 
			;
		
		for (size_t i = 1; i < dist.size(); ++i)  {   
			if (dist[min_ind] > dist[i] && !mark[i]) { 
				min_ind = i;
			}
		}
		return min_ind;
	};	 

	auto is_all_process = [&]() -> bool { 
		return std::find (mark.begin(), mark.end(), false) == mark.end(); 
	};

	while (!is_all_process()) { 
		size_t ind = find_min();

		for (auto const & arc : graph[ind]) { 
			if (!mark[arc.first] && dist[arc.first] > dist[ind] + arc.second) { 	
				dist[arc.first] =	dist[ind] + arc.second;
			} 
		} 

		mark[ind] = true;
	}
}

template<class graph_t>
void binary_heap_dijkstra(graph_t const & graph, size_t max_cost, size_t start, std::vector<int64_t>& dist, size_t number_edges = INF) { 
	std::vector<bool> mark(dist.size(), false); 
	binary_heap_t heap;
	heap.push(std::make_pair(0, start));

	dist[start] = 0;
	while (!heap.empty()) { 
		auto item = heap.top();
		heap.pop();

		for (auto const & arc : graph[item.second]) { 
			if (!mark[arc.first] && dist[arc.first] > dist[item.second] + arc.second) { 	
				dist[arc.first] =	dist[item.second] + arc.second;
				heap.push(std::make_pair(dist[item.second] + arc.second, arc.first));				
			}
		} 

		mark[item.second] = true;
	}
} 

template<class graph_t>
void radix_heap_dijkstra(graph_t const & graph, size_t max_cost, size_t start, std::vector<int64_t>& dist, size_t number_edges = INF) {	
	std::vector<bool> mark(dist.size(), false); 
	RadixHeap<size_t> heap(max_cost, graph.size(), number_edges);
	heap.add(std::make_pair(0, start));
	
	dist[start] = 0;
	while (!heap.empty()) { 
		auto item = heap.extract_min();
		for (auto const & arc : graph[item.second]) {  
		if (!mark[arc.first] && dist[arc.first] > dist[item.second] + arc.second) { 	
				
				if (dist[arc.first] < INF) { 
					heap.decreaseKey(dist[item.second] + arc.second, std::make_pair(dist[arc.first], arc.first));
				} else { 
					heap.add(std::make_pair(dist[item.second] + arc.second, arc.first));
				} 

				dist[arc.first] =	dist[item.second] + arc.second;
			}
		} 

		mark[item.second] = true;
	}
}

template<class graph_t>
void lazy_radix_heap_dijkstra(graph_t const & graph, size_t max_cost, size_t start, std::vector<int64_t>& dist, size_t number_edges = INF) {	
	std::vector<bool> mark(dist.size(), false); 
	LazyRadixHeap<size_t> heap(max_cost, graph.size(), number_edges);
	heap.add(std::make_pair(0, start));
	
	dist[start] = 0;
	while (!heap.empty()) { 
		auto item = heap.extract_min();
		for (auto const & arc : graph[item.second]) {  
		if (!mark[arc.first] && dist[arc.first] > dist[item.second] + arc.second) { 	
				
				if (dist[arc.first] < INF) { 
					heap.decreaseKey(dist[item.second] + arc.second, std::make_pair(dist[arc.first], arc.first));
				} else { 
					heap.add(std::make_pair(dist[item.second] + arc.second, arc.first));
				} 

				dist[arc.first] =	dist[item.second] + arc.second;
			}
		} 

		mark[item.second] = true;
	}
}

#endif 