#ifndef RADIXHEAP_HPP
#define RADIXHEAP_HPP

#include <cassert>
#include <cmath>
#include <algorithm>
#include <vector>
#include <list>

template<class elem_t>
struct RadixHeap { 
	typedef std::pair<long long, elem_t> item_t;
	typedef std::vector<item_t> bucket_t;

	RadixHeap(long long max_cost)
	: m_size(0) 
	, last_deleted(0) 
	, buckets(static_cast<size_t>(ceil(log2(max_cost + 1))))
	, summary(std::numeric_limits<int>::max())
	, count_add(0)
	, count_decrease(0)
	{
	}

	RadixHeap(long long max_cost, size_t number_vertices, size_t number_edges)
	: m_size(0) 
	, last_deleted(0) 
	, buckets(static_cast<size_t>(ceil(log2(max_cost + 1))))
	, summary(number_vertices * static_cast<size_t>(ceil(log2(max_cost + 1))) + number_edges)
	, count_add(0)
	, count_decrease(0)
	{ 
	}

	size_t size() const { // O(1)
		return m_size;
	}

	bool empty() const { // O(1)
		return (m_size == 0);
	}

	void add(item_t const & elem) { // O(1)
		++count_add; 
		assert((count_add + count_decrease) <= summary);
		size_t ind = get_index_element(elem.first); 
		buckets[ind].push_back(elem);		
		++m_size;
	}

	void decreaseKey(item_t const & elem, long long new_prior) { // O(1)
		++count_decrease; 
		assert((count_add + count_decrease) <= summary);

		if (m_size == 0) { 
			return;
		}

		size_t ind = get_index_element(elem.first);
		auto iter = std::find(buckets[ind].begin(), buckets[ind].end(), elem);
		buckets[ind].erase(iter);
		
		size_t new_ind = get_index_element(new_prior);
		buckets[new_ind].push_back(item_t(new_prior, elem.second));
	}

	item_t extract_min() { // O(logC) - amor
		//std::cerr << "extract_min run " << std::endl;
		if (m_size == 0) { 
			return item_t();
		}

		if (!buckets[0].empty()) { 
			item_t deleted = buckets[0].back();
			last_deleted = deleted.first;
			buckets[0].pop_back();
			--m_size;
			return deleted;
		} else {
			size_t ind = 1;  
			for (; ind < buckets.size() && buckets[ind].empty(); ++ind)
				;

			auto iter = std::min_element(buckets[ind].begin(), buckets[ind].end(), [](item_t const & f, item_t const & s) {
				return f.first < s.first;
			});

			item_t deleted = *iter;
			last_deleted  = deleted.first;
			--m_size; 

			//move all elements from bucket[ind]
			bucket_t bucket;
			for (auto it = buckets[ind].begin(); it != buckets[ind].end(); ++it) { 
				if (it != iter) { 
					size_t new_ind = get_index_element(it->first);
					if (new_ind != buckets.size() - 1) {
						buckets[new_ind].push_back(*it);
					} else { 
						bucket.push_back(*it);
					} 
				}
			} 
			buckets[ind] = bucket;
			return deleted;
		}
	}

	void print_buckets() const {
		std::clog << "new stamp " << std::endl;

		for (size_t i = 0; i < buckets.size(); ++i) {
			std::clog << i << ": ";
			for (auto it = buckets[i].begin(); it != buckets[i].end(); ++it) { 
				std::clog << it->first << " ";
			}
			std::clog << std::endl;
		} 
	}
	
private: 
	size_t get_index_element(long long prior) { 
		size_t ind = higest_bit(prior ^ last_deleted) + 1;
		if (ind > buckets.size() - 1) { 
			ind = buckets.size() - 1;
		}
		return ind;
	}

	size_t higest_bit(long long x) { 
		if (x == 0) { 
			return -1;
		} else {
			size_t r = 0;
			while (x >>= 1) { 
				++r;
			}
			return r;
		}
	}

private:
	size_t m_size; 
	long long last_deleted;
	std::vector<bucket_t> buckets;

	//Test variables
	long long summary; 
	size_t count_add; 
	size_t count_decrease; 
};


#endif