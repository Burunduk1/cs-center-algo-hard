#ifndef RADIXHEAP_HPP
#define RADIXHEAP_HPP

#include <cmath>
#include <cassert>

#include <list>
#include <vector>

#include <algorithm>

template<class elem_t>
class RadixHeap { 
	typedef std::pair<int64_t, elem_t> item_t;

	struct node_t { 
		int64_t prior; 
		elem_t elem; 
		size_t ind_bucket;
		node_t* next; 
		node_t* prev;

		node_t(int64_t p, elem_t e, size_t ind = 0, node_t* n = nullptr, node_t* pr = nullptr) 
		: prior(p) 
		, elem(e)
		, ind_bucket(ind)
		, next(n)
		, prev(pr)
		{ 
		}
	}; 
public: 
	RadixHeap(size_t max_cost, size_t number_vertices)
	: m_size(0) 
	, last_deleted(0) 
	, buckets(static_cast<size_t>(ceil(log2(max_cost + 1))), nullptr)
	, all_elements(number_vertices, nullptr)
	, summary(std::numeric_limits<size_t>::max())
	, count_add(0)
	, count_decrease(0)
	{ 
	}

	RadixHeap(size_t max_cost, size_t number_vertices, size_t number_edges)
	: m_size(0) 
	, last_deleted(0) 
	, buckets(static_cast<size_t>(ceil(log2(max_cost + 1))), nullptr)
	, all_elements(number_vertices, nullptr)
	, summary(number_vertices * static_cast<size_t>(ceil(log2(max_cost + 1))) + number_edges)
	, count_add(0)
	, count_decrease(0)
	{ 
	}

	inline size_t size() const { // O(1)
		return m_size;
	}

	inline bool empty() const { // O(1)
		return (m_size == 0);
	}

	inline void add(item_t const & elem) { // O(1)
		//std::cerr << "add " << elem.second << std::endl;
		++count_add; 
		assert((count_add + count_decrease) <= summary);
		all_elements[elem.second] = new node_t(elem.first, elem.second);
		add_node(get_index_element(elem.first), all_elements[elem.second]);
		++m_size;
	}

	inline void decreaseKey(int64_t new_prior, item_t const & elem) { // O(1)
		//std::cerr << "decreaseKey " << elem.second << std::endl;
		++count_decrease; 
		assert((count_add + count_decrease) <= summary);
		assert(m_size != 0);	
		replace_node(all_elements[elem.second]->ind_bucket, get_index_element(new_prior), all_elements[elem.second]);
		all_elements[elem.second]->prior = new_prior;
	}

	item_t extract_min() { // O(logC) - amor
		//std::cerr << "extract min " << std::endl;
		--m_size;	

		if (buckets[0] != nullptr) { 
			item_t deleted = remove_node(0, buckets[0]); 
			last_deleted = deleted.first;
			return deleted;
		} 

		size_t ind = 1;  
		for (; ind < buckets.size() && buckets[ind] == nullptr; ++ind)
			;

		node_t* min_iter = buckets[ind];
		for (auto p = buckets[ind]; p != nullptr; p = p->next) { 
			if (min_iter->prior > p->prior) { 
				min_iter = p;
			}
		}

		item_t deleted = remove_node(ind, min_iter);
		last_deleted = deleted.first;

		//move all elements from bucket[ind]
		for (auto it = buckets[ind]; it != nullptr;) { 
			size_t new_ind = get_index_element(it->prior);
			if (new_ind != buckets.size() - 1) {
				it = replace_node(ind, new_ind, it); 
			} else { 
				it = it->next;
			}
		} 
		return deleted;
	}

	void print_buckets() { 
		for (size_t i = 0; i < buckets.size(); ++i) { 
			std::clog << i << ": "; 
			for (auto p = buckets[i]; p != nullptr; p = p->next) { 
				std::clog << "(" << p->prior << ", " << p->elem << ") ";
			} 
			std::clog << std::endl;
		}
	}

	~RadixHeap() { 
		for (size_t i = 0; i < all_elements.size(); ++i) { 
			delete all_elements[i];
		}
	}

private: 
	inline node_t* replace_node(size_t old_ind, size_t new_ind, node_t* it) { 
		node_t* ret = it->next;
		remove_node(old_ind, it); 
		add_node(new_ind, it);
		return ret;
	}

	inline item_t add_node(size_t ind, node_t* it) { 
		all_elements[it->elem]->ind_bucket = ind;
		it->next = buckets[ind]; it->prev = nullptr;
		buckets[ind] = it;
		if (buckets[ind]->next) buckets[ind]->next->prev = it;
	}

	inline item_t remove_node(size_t ind, node_t* it) { 
		item_t p(it->prior, it->elem); 
		if (it->prev) it->prev->next = it->next;
		if (it->next) it->next->prev = it->prev;
		if (buckets[ind] == it) buckets[ind] = buckets[ind]->next;
		return p;
	}

	inline size_t get_index_element(int64_t prior) { 
		size_t ind = higest_bit(prior ^ last_deleted) + 1;
		if (ind > buckets.size() - 1) { 
			ind = buckets.size() - 1;
		}
		return ind;
	}

	inline size_t higest_bit(int64_t x) { 
		if (x == 0) { 
			return -1;
		} else {
			size_t r = 0;
			while (x >>= 1) { 
				++r;
			}
			return r;
		}
	}

private:
	size_t m_size; 
	int64_t last_deleted;
	std::vector<node_t*> buckets;
	std::vector<node_t*> all_elements;

	//Test variables
	size_t summary; 
	size_t count_add; 
	size_t count_decrease; 
};


#endif