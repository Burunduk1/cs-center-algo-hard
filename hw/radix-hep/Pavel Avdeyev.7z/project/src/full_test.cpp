#include <chrono>
#include <cstdlib>
#include <cassert>
#include <iostream>
#include <fstream>
#include <limits>
#include <random>

#include "dijkstra.hpp"

#define NUMBER_TEST 13

typedef std::pair<size_t, size_t> arc_t;
typedef std::vector<std::list<arc_t> > graph_t;
typedef void (*dijkstra_func_t)(graph_t const&, size_t, size_t, std::vector<int64_t>&, size_t);

/*
 * Different function for read datasets and answers
 */
graph_t read_list_edges(std::ifstream& in, size_t number_vertices, size_t count_edges) { 
	graph_t graph(number_vertices);

	for (size_t i = 0; i < count_edges; ++i) { 
		size_t s = 0; 
		size_t f = 0; 
		size_t weight = 0;
		in >> s >> f >> weight;

		graph[s].push_back(arc_t(f, weight));
	}

	return graph;
}

void read_answer(std::ifstream& in, std::vector<int64_t> & answer, size_t size) { 
	for (size_t i = 0; i < size; ++i) { 
		int temp = 0; 
		in >> temp; 

		if (temp == -1) { 
			answer.push_back(INF);
		} else { 
			answer.push_back(temp);
		}
	}
}

/* 
 * Various generators for graphs
 */
graph_t generate_worm_graph(size_t number_vertices, size_t max_cost) { 
	graph_t graph(number_vertices);
	std::random_device rd;
	std::mt19937 re(rd());
	std::uniform_int_distribution<size_t> ui(1, max_cost);

	for (size_t i = 0; i < number_vertices - 1; ++i) { 
		size_t weight = ui(re); 
		graph[i].push_back(std::make_pair(i + 1, weight));
	}

	return graph;
}

graph_t generate_complete_graph(size_t number_vertices, size_t max_cost) { 
	graph_t graph(number_vertices);
	std::random_device rd;
	std::mt19937 re(rd());
	std::uniform_int_distribution<size_t> ui(1, max_cost);

	for (size_t i = 0; i < number_vertices; ++i) { 
		for (size_t j = 0; j < number_vertices; ++j) { 
			if (i != j) {  
				size_t weight = ui(re);
				graph[i].push_back(std::make_pair(j, weight));
			} 
		}
	} 

	return graph;
}

graph_t generate_random_graph(size_t number_vertices, size_t left_degree, size_t right_degree, 
																size_t min_cost,  size_t max_cost) { 
	std::random_device rd;
	std::mt19937 re(rd());
	graph_t graph(number_vertices);

	std::vector<size_t> vertex_degree(number_vertices, 0);
	std::uniform_int_distribution<size_t> u_degree(left_degree, right_degree);
	for (size_t i = 0; i < number_vertices; ++i) { 
		vertex_degree[i] = u_degree(re);
	}	
		
	std::uniform_int_distribution<size_t> u_weight(min_cost, max_cost);
	for (size_t i = 0; i < number_vertices; ++i) { 
		std::uniform_int_distribution<size_t> u_vertex(0, number_vertices - 1);
		for (size_t j = 0; j < vertex_degree[i]; ++j) { 
			size_t vertex = u_vertex(re);
			size_t weight = u_weight(re);
			if (vertex != i) {  
				graph[i].push_back(std::make_pair(vertex, weight));
			} 
		} 
	} 

	return graph;
}

/*
 * Correctness and efficiency checkers for dijkstra.
 */
void check_dijkstra(std::string const & name, dijkstra_func_t dijkstra) { 
	size_t right_answer = 0;
	size_t wrong_answer = 0;

	for (int i = 1; i < NUMBER_TEST; ++i) { 
		size_t number_vertices = 0; 
		size_t number_edges = 0;
		size_t max_cost = 0;
		size_t start = 0;

		std::string test_file = "tests/input" + std::to_string(i) + ".txt";
		std::ifstream in(test_file.c_str());
		in >> number_vertices >> number_edges >> max_cost >> start;
		auto graph = read_list_edges(in, number_vertices, number_edges);
		in.close(); 

		std::vector<int64_t> dist(graph.size(), INF);
		dijkstra(graph, max_cost, start, dist, number_edges);

		std::string answer_file = "tests/answer" + std::to_string(i) + ".txt"; 
		std::vector<int64_t> answer;
		std::ifstream ans(answer_file.c_str());
		read_answer(ans, answer, dist.size());
		ans.close();
		
		if (answer == dist) { 
			++right_answer; 
		} else { 
			++wrong_answer;
		}
	}

	std::cout << name << "\n\tPass: " << right_answer << " tests\n\tWA: " << wrong_answer 
			<< " tests" <<  std::endl << std::endl; 
}

void test_effiency_dijkstra(graph_t & graph, size_t max_cost, dijkstra_func_t dijkstra, std::string const & name) { 
	size_t start = 0;
	std::vector<int64_t> dist(graph.size(), INF);
	auto start_time = std::chrono::high_resolution_clock::now(); 
	dijkstra(graph, max_cost, start, dist, INF);
	auto end_time = std::chrono::high_resolution_clock::now(); 
	std::cout << name << ": " << std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time).count() << " milliseconds" << std::endl;
}

/*
 * Start point
 */
int main(int argc, char* argv[]) {
	int const NUMBER_ALGO = 3; 
	std::cout << "\t\tVERIFY THAT ALL IS OK" << std::endl;
	check_dijkstra("Dijkstra with array", &stupid_dijkstra);
	check_dijkstra("Dijkstra with STL priority queue", &binary_heap_dijkstra);
	check_dijkstra("Dijkstra with radix heap", &radix_heap_dijkstra);
	check_dijkstra("Dijkstra with lazy radix heap", &lazy_radix_heap_dijkstra);
	
	std::cout << "\t\tTEST EFFICIENTY ALGORITHM" << std::endl << std::endl;
	dijkstra_func_t funcs[NUMBER_ALGO] = {&binary_heap_dijkstra, 
																				&radix_heap_dijkstra, 
																				&lazy_radix_heap_dijkstra};
	std::string names[NUMBER_ALGO] = {"Dijkstra with STL priority queue", 
																		"Dijkstra with radix heap", 
																		"Dijkstra with lazy radix heap"};

	for (size_t vertices = 100000; vertices <= 100000; vertices *= 10) { 
		for (size_t max_cost = 100; max_cost <= 1000000000; max_cost *= 10) {
			std::cout << "\tTest on random graph with " << vertices << " vertices and out degree [50,90] and size bucket " << max_cost << std::endl; 
			graph_t graph = generate_random_graph(vertices, 50, 90, 1, max_cost);	
			for (size_t i = 0; i < NUMBER_ALGO; ++i) {  
				test_effiency_dijkstra(graph, max_cost, funcs[i], names[i]);
			} 
			std::cout << std::endl;
		}
	}

	for (size_t vertices = 100000; vertices <= 100000; vertices *= 10) { 
		for (size_t max_cost = 100; max_cost <= 1000000000; max_cost *= 10) {
			std::cout << "\tTest on random graph with " << vertices << " vertices and out degree [80,120] and size bucket " << max_cost << std::endl; 
			graph_t graph = generate_random_graph(vertices, 80, 120, 1, max_cost);
			for (size_t i = 0; i < NUMBER_ALGO; ++i) {  
				test_effiency_dijkstra(graph, max_cost, funcs[i], names[i]);
			} 
			std::cout << std::endl;
		}
	}

	for (size_t d = 1; d < 5; ++d) {  
		for (size_t max_cost = 100; max_cost <= 1000000000; max_cost *= 10) {
			std::cout << "\tTest on random graph with 10^6"  << " vertices with " << d << "*N edges and size bucket " << max_cost << std::endl; 
			graph_t graph = generate_random_graph(1000000, d, d, 1, max_cost);
			for (size_t i = 0; i < NUMBER_ALGO; ++i) {  
				test_effiency_dijkstra(graph, max_cost, funcs[i], names[i]);
			} 
			std::cout << std::endl;
		}
	} 

	return 0;
} 