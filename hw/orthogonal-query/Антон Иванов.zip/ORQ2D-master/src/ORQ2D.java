public interface ORQ2D {
  P[] query(int x0, int y0, int w, int h);
}
