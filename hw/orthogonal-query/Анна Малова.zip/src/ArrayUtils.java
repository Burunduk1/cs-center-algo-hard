public class ArrayUtils {
    public static Point[] mergeArrays(Point[] a, Point[] b, int dim) {
        Point[] c = new Point[a.length + b.length];
        int pa = 0;
        int pb = 0;
        int pc = 0;
        while (pa < a.length && pb < b.length) {
            c[pc++] = (Point.comparator(dim).compare(a[pa], b[pb]) < 0) ? a[pa++] : b[pb++];
        }

        while (pa < a.length) {
            c[pc++] = a[pa++];
        }

        while (pb < b.length) {
            c[pc++] = b[pb++];
        }

        return c;
    }

    public static int binarySearch(int[] a, int key) {
        int l = -1;
        int r = a.length;
        while (r - l > 1) {
            int m = (l + r) / 2;
            if (a[m] >= key) {
                r = m;
            } else {
                l = m;
            }
        }
        return r;
    }
}
