import java.util.stream.IntStream;

public class Rectangle {
    Point low, high;

    public Rectangle(Point low, Point high) {
        this.low = low;
        this.high = high;
    }

    public int dim() {
        return low.dim();
    }

    public boolean inside(Point p) {
        return IntStream.range(0, p.dim()).allMatch(
                (i) -> (low.coordinates[i] <= p.coordinates[i]) && (p.coordinates[i] <= high.coordinates[i])
        );
    }

    public Point genInside() {
        return Point.genRandomPoint(low, high);
    }

    public Point genOutside(int minX, int maxX) {
        Point res = Point.genRandomPoint(dim(), minX, maxX);
        while (inside(res)) {
            res = Point.genRandomPoint(dim(), minX, maxX);
        }
        return res;
    }

    public static Rectangle genRandomRectangle(int dim, int minX, int maxX) {
        Point low = Point.genRandomPoint(dim, minX, maxX);
        Point high = Point.genRandomPoint(low, new Point(IntStream.iterate(maxX, i -> maxX).limit(dim).toArray()));

        return new Rectangle(low, high);
    }

    @Override
    public String toString() {
        return "Rectangle{" +
                "low=" + low +
                ", high=" + high +
                '}';
    }
}
