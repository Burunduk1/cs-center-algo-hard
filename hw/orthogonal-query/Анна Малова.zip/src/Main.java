import java.util.ArrayList;
import java.util.HashSet;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main {
    static double build = 0;
    static double naive = 0;
    static double fc = 0;

    public static ArrayList<Point>[] solve(Point[] points, Rectangle[] rectangles) {
        long time = System.currentTimeMillis();
        LRTree tree = LRTree.buildTree(points);

        build += (System.currentTimeMillis() * 1.0 - time) / 1000;
        
        time = System.currentTimeMillis();

        ArrayList<Point>[] result = new ArrayList[rectangles.length];
        for (int i = 0; i < rectangles.length; i++) {
            result[i] = tree.query(rectangles[i]);
        }

        fc += (System.currentTimeMillis() * 1.0 - time) / 1000;

        return result;
    }

    public static ArrayList<Point>[] naiveSolve(Point[] points, Rectangle[] rectangles) {
        long time = System.currentTimeMillis();
        ArrayList<Point>[] result = new ArrayList[rectangles.length];
        for (int i = 0; i < rectangles.length; i++) {
            result[i] = new ArrayList<>();
            for (int j = 0; j < points.length; j++) {
                if (rectangles[i].inside(points[j])) {
                    result[i].add(points[j]);
                }
            }
        }

         naive += (System.currentTimeMillis() * 1.0 - time) / 1000;

        return result;
    }

    static void correctnessTest() {
        for (int inside = 90; inside <= 100; inside++) {
            for (int outside = 90; outside <= 100; outside++) {
                for (int dim = 2; dim <= 6; dim++) {
                    CorrectnessTest t = new CorrectnessTest(dim, 0, 10000, inside, outside);
                    Point[] points = Stream.concat(t.inside.stream(), t.outside.stream()).toArray(Point[]::new);
                    ArrayList<Point>[] ans = solve(points, new Rectangle[]{t.r});
                    if (!t.check(ans[0])) {
                        System.out.println(t.toString());
                        System.out.println(ans.toString());
                    }
                }
            }
        }
        System.err.println("Correct");
    }

    static void speedTest() {
        long time;
        SpeedTest test;
        int tn = 2;
        for (int i = 0; i < tn; i++) {
            test = new SpeedTest(4, -10000, 10000, 100000, 1000);

            solve(test.points, test.rectangles);

            naiveSolve(test.points, test.rectangles);

            System.err.println(i);
        }

        System.out.println("Fractional Cascading build tree time: " + build / tn);
        System.out.println("Fractional Cascading solution: " + fc / tn);
        System.out.println("Naive solution: " + naive / tn);
    }

    public static void main(String[] args) throws Exception {
       //correctnessTest();
       speedTest();

    }

    public static class CorrectnessTest {
        public CorrectnessTest(int dim, int minX, int maxX, int insideCnt, int outsideCnt) {
            this.r = Rectangle.genRandomRectangle(dim, minX, maxX);

            Supplier<Point> out = () -> r.genOutside(minX, maxX);
            this.inside = Stream.generate(r::genInside).limit(insideCnt).collect(Collectors.toCollection(HashSet::new));
            this.outside = Stream.generate(out).limit(outsideCnt).collect(Collectors.toCollection(HashSet::new));
        }

        boolean check(ArrayList<Point> ans) {
            HashSet<Point> ansSet = new HashSet<>(ans);
            return inside.equals(ansSet);
        }

        @Override
        public String toString() {
            return "Test{" +
                    "r=" + r +
                    ", inside=" + inside +
                    ", outside=" + outside +
                    '}';
        }

        Rectangle r;
        HashSet<Point> inside;
        HashSet<Point> outside;
    }

    public static class SpeedTest {
        public SpeedTest(int dim, int minX, int maxX, int pointsCnt, int rectanglesCnt) {
            Supplier<Rectangle> r = () -> Rectangle.genRandomRectangle(dim, minX, maxX);
            rectangles = Stream.generate(r).limit(rectanglesCnt).toArray(Rectangle[]::new);
            Supplier<Point> p = () -> Point.genRandomPoint(dim, minX, maxX);
            points = Stream.generate(p).limit(pointsCnt).toArray(Point[]::new);
        }

        Rectangle[] rectangles;
        Point[] points;
    }
}
