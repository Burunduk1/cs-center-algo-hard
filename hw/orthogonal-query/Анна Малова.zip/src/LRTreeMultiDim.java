import java.util.ArrayList;
import java.util.HashMap;

public class LRTreeMultiDim extends LRTree {
    LRTree innerTree;

    protected LRTreeMultiDim(int dim) {
        this.dim = dim;
    }

    protected LRTreeMultiDim(Point[] points, int dim) {
        super(points, dim);
    }

    @Override
    protected void buildTree(int left, int right, HashMap<Integer, ArrayList<Point>> hm, int[] unique) {
        buildSubTrees(left, right, hm, unique);
        innerTree = dim == 3 ? new LRTree2D(points) : new LRTreeMultiDim(points, dim - 1);
    }

    @Override
    protected ArrayList<Point> innerQuery(int low, int high, Rectangle r, int startLink) {
        return innerTree.query(r);
    }
}
