import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public abstract class LRTree {
    protected LRTree leftTree, rightTree;
    protected int[] unique;
    protected int dim;
    protected int left, right;
    protected Point[] points;

    public LRTree() {
    }

    protected LRTree(int dim) {
        this.dim = dim;
    }

    public static LRTree buildTree(Point[] points) {
        int dim = points[0].coordinates.length;
        if (dim == 2) {
            return new LRTree2D(points);
        } else {
            return new LRTreeMultiDim(points, dim);
        }
    }

    protected LRTree(Point[] points, int dim) {
        this.dim = dim;
        unique = Arrays.asList(points).stream().mapToInt((p) -> p.coordinates[dim - 1]).distinct().toArray();
        Arrays.sort(unique);

        Arrays.sort(points, Point.comparator(dim));

        HashMap<Integer, ArrayList<Point>> hm = new HashMap<>();
        for (Point p : points) {
            hm.putIfAbsent(p.coordinates[dim - 1], new ArrayList<>());
            hm.get(p.coordinates[dim - 1]).add(p);
        }

        buildTree(0, unique.length, hm, unique);
    }

    protected abstract void buildTree(int left, int right, HashMap<Integer, ArrayList<Point>> hm, int[] unique);

    protected void buildSubTrees(int left, int right, HashMap<Integer, ArrayList<Point>> hm, int[] unique) {
        this.left = left;
        this.right = right;
        this.unique = unique;
        if (right - left == 1) {
            ArrayList<Point> points = hm.get(unique[left]);
            this.points = new Point[points.size()];
            for (int i = 0; i < this.points.length; i++) {
                this.points[i] = points.get(i);
            }
        } else {
            int middle = (left + right) / 2;

            if (dim == 2) {
                this.leftTree = new LRTree2D();
                this.rightTree = new LRTree2D();
            } else {
                this.leftTree = new LRTreeMultiDim(dim);
                this.rightTree = new LRTreeMultiDim(dim);
            }

            this.leftTree.buildTree(left, middle, hm, unique);
            this.rightTree.buildTree(middle, right, hm, unique);

            this.points = ArrayUtils.mergeArrays(this.leftTree.points, this.rightTree.points, dim - 1);
        }
    }

    protected int getLeftLink(int startLink) {
        return -1;
    }

    protected int getRightLink(int startLink) {
        return -1;
    }

    protected int getRootLink(int low) {
        return -1;
    }

    public ArrayList<Point> query(int low, int high, Rectangle r, int startLink) {
        if (low >= right || left >= high) {
            return new ArrayList<>();
        }

        if (low <= left && right <= high) {
            return innerQuery(low, high, r, startLink);
        }

        ArrayList<Point> ansLeft = leftTree.query(low, high, r, getLeftLink(startLink));
        ArrayList<Point> ansRight = rightTree.query(low, high, r, getRightLink(startLink));
        ansLeft.addAll(ansRight);
        return ansLeft;
    }

    protected abstract ArrayList<Point> innerQuery(int low, int high, Rectangle r, int startLink);

    public ArrayList<Point> query(Rectangle r) {
        int low = ArrayUtils.binarySearch(unique, r.low.coordinates[dim - 1]);
        int high = ArrayUtils.binarySearch(unique, r.high.coordinates[dim - 1] + 1);
        if (low < high) {
            int startLink = getRootLink(r.low.coordinates[0]);
            return query(low, high, r, startLink);
        }

        return new ArrayList<>();
    }

    @Override
    public String toString() {
        String ans = "";
        if (leftTree != null)
            ans += leftTree.toString();
        ans += Arrays.toString(points);
        if (rightTree != null)
            ans += rightTree.toString();
        return ans;
    }
}
