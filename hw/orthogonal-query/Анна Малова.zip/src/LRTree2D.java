import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.OptionalInt;
import java.util.stream.IntStream;

public class LRTree2D extends LRTree {
    protected int[] FCLeftLinks;
    protected int[] FCRightLinks;

    protected LRTree2D(Point[] points) {
        super(points, 2);
    }

    protected LRTree2D() {
        super(2);
    }

    private static int[] calculateFCLinks(Point[] parent, Point[] child) {
        int[] FCLinks = new int[parent.length];
        Arrays.fill(FCLinks, -1);
        OptionalInt link = OptionalInt.of(0);

        for (int i = 0; i < parent.length; i++) {
            final int fi = i;
            link = IntStream.range(link.getAsInt(), child.length).
                    filter(k -> child[k].coordinates[0] >= parent[fi].coordinates[0]).
                    findFirst();
            if (link.isPresent()) {
                FCLinks[fi] = link.getAsInt();
            } else {
                break;
            }
        }
        return FCLinks;
    }

    @Override
    protected void buildTree(int left, int right, HashMap<Integer, ArrayList<Point>> hm, int[] unique) {
        buildSubTrees(left, right, hm, unique);

        if (leftTree != null) {
            FCLeftLinks = calculateFCLinks(points, leftTree.points);
        }
        if (rightTree != null) {
            FCRightLinks = calculateFCLinks(points, rightTree.points);
        }
    }

    @Override
    protected int getLeftLink(int link) {
        return (link == -1 || link >= FCLeftLinks.length) ? -1 : FCLeftLinks[link];
    }

    @Override
    protected int getRightLink(int link) {
        return (link == -1 || link >= FCRightLinks.length) ? -1 : FCRightLinks[link];
    }

    @Override
    protected int getRootLink(int low) {
        return ArrayUtils.binarySearch(Arrays.asList(points).stream().mapToInt((p) -> p.coordinates[0]).toArray(), low);
    }

    @Override
    protected ArrayList<Point> innerQuery(int low, int high, Rectangle r, int startLink) {
        ArrayList<Point> ans = new ArrayList<>();
        while (startLink != -1 && startLink < points.length && points[startLink].coordinates[0] <= r.high.coordinates[0]) {
            ans.add(points[startLink++]);
        }

        return ans;
    }
}
