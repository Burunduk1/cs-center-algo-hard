import java.util.Arrays;
import java.util.Comparator;
import java.util.Random;
import java.util.function.IntUnaryOperator;
import java.util.stream.IntStream;

public class Point {
    int coordinates[];

    public Point(int[] coordinates) {
        this.coordinates = coordinates;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Point point = (Point) o;

        return Arrays.equals(coordinates, point.coordinates);
    }

    public int dim() {
        return coordinates.length;
    }

    @Override
    public int hashCode() {
        return coordinates != null ? Arrays.hashCode(coordinates) : 0;
    }

    @Override
    public String toString() {
        return "Point{" +
                "coordinates=" + Arrays.toString(coordinates) +
                '}';
    }

    public static Comparator<Point> comparator(final int dim) {
        return (p1, p2) -> dim > 1 && p1.coordinates[dim - 1] == p2.coordinates[dim - 1]
                ? p1.coordinates[dim - 2] - p2.coordinates[dim - 2]
                : p1.coordinates[dim - 1] - p2.coordinates[dim - 1];
    }

    final static Random rnd = new Random(13);

    public static Point genRandomPoint(Point low, Point high) {
        int dim = low.dim();
        IntUnaryOperator rndX = (int i) -> low.coordinates[i] + rnd.nextInt(high.coordinates[i] - low.coordinates[i] + 1);

        return new Point(IntStream.range(0, dim).map(rndX).toArray());
    }

    public static Point genRandomPoint(int dim, int minX, int maxX) {
        return new Point(rnd.ints(dim, minX, maxX).toArray());
    }
}
