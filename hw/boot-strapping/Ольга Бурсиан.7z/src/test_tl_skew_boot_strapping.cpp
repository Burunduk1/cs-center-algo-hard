#include <vector>
#include <algorithm>
#include <ctime>
#include "skew_heap.h"
#include "boot_strapping.h"

#define forn(i, n) for (int i = 0; i < (int)(n); i++)

void gen( int n, vector <int> &a ) {
  a.resize(n);
  forn(i, n)
    a[i] = rand();
}

const int maxN = 1e6;
B<int, skew_heap> h;

int main() {
  vector <int> x;
  int n = maxN;
  forn(t, 10) { // number of tests
    gen(n, x);
    forn(i, n)
      h.add(x[i]);
    forn(i, n)
      h.extract_min();
  }
  fprintf(stderr, "Test for TL for boot strapping with skew heap: OK. Time = %.2f\n", 1. * clock() / CLOCKS_PER_SEC);
}
