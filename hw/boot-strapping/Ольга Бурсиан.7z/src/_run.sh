for suf in wa_leftist_heap wa_skew_heap tl_leftist_heap tl_skew_heap wa_leftist_boot_strapping wa_skew_boot_strapping tl_leftist_boot_strapping tl_skew_boot_strapping tl_compare_10_5 tl_compare_10_6; do 
  g++ -O2 -Wall -std=c++11 test_$suf.cpp -o test_$suf && ./test_$suf
done

