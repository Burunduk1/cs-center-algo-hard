#include <vector>
#include <algorithm>
#include "leftist_heap.h"
#include "boot_strapping.h"

#define forn(i, n) for (int i = 0; i < (int)(n); i++)

void gen( int n, vector <int> &a ) {
  a.resize(n);
  forn(i, n)
    a[i] = rand();
}

const int maxN = 100;
B<int, leftist_heap> b;

int main() {
  vector <int> x, ns = {3, 5, 10, 20, maxN};
  for (auto n : ns) // size of test
    forn(t, 10000) { // number of tests
      // test add + extract + min
      gen(n, x);
      forn(i, n)
      {
        //b.print();
        //printf("x[i]=%d\n", x[i]);
        b.add(x[i]);
      }
      forn(i, n) {
        //b.print();
        //printf("%d=%d\n", b.min(), *it);
        auto it = min_element(x.begin(), x.end());
        assert(b.min() == *it);
        assert(b.extract_min() == *it);
        x.erase(it);
      }
    }
  fprintf(stderr, "Test for WA for boot strapping with skew heap: OK.\n");
}



