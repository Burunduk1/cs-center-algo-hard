#ifndef BOOT_STRAPPING_H
#define BOOT_STRAPPING_H

#include <algorithm>

using namespace std;

template<class T, template<typename> class H>
struct B 
{
  T x;
  H<B> h;
  bool empty;
  B()
  {
    empty = true;
    x = T();
    h = H<B>();
  }
  B(T x1)
  {
    empty = false;
    x = x1;
    h = H<B>();
  }
  B merge(B b1, B b2)
  {
    if(b1.x > b2.x)
      swap(b1, b2);
    b1.h.add(b2);
    return b1;
  }
  void add(T x)
  {
    if(empty)
      *this = B(x);
    else
      *this = merge(*this, B(x));
  }
  T min()
  {
    return x;    
  }  
  T extract_min()
  {
    assert(!empty);
    T res = x;
    if(h.empty())
      empty = true;
    else
    {
      B b1 = h.extract_min();
      x = b1.x;
      h.selfmerge(b1.h.root);
    }
    return res;    
  }
  void print()
  {
    if(empty)
      return;
    cout << "x=" << x;
    if(!(h.empty()))
      cout << " h.x=" << ((h.min()).x);
    cout << "\n";
  }  
};

template<class T, template<typename> class H>
bool operator>(B<T, H> b1, B<T, H> b2)
{
  return b1.x > b2.x;
}

#endif // BOOT_STRAPPING_H



