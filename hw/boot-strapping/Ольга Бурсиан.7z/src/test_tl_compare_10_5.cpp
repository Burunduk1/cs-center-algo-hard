#include <vector>
#include <queue>
#include <set>
#include <algorithm>
#include <ctime>
#include "leftist_heap.h"
#include "skew_heap.h"
#include "boot_strapping.h"
                                                                                 
#define forn(i, n) for (int i = 0; i < (int)(n); i++)

unsigned R() { return (rand() << 15) | rand(); } // mingw g++ has 15-bit rand()

void gen( int n, vector <int> &a ) {
  a.resize(n);
  forn(i, n)
    a[i] = R();
}

const int maxN = 1e5;
leftist_heap<int> lh;
skew_heap<int> sh;
B<int, leftist_heap> Blh;
B<int, skew_heap> Bsh;

double start = 0;
#define timeStamp(...) fprintf(stderr, __VA_ARGS__, (clock() - start) / CLOCKS_PER_SEC), start = clock()

int main() {
  vector <int> x;
  int n = maxN;
  fprintf(stderr, "10^5\n");
  gen(n, x);
  timeStamp("input is generated: %.2f\n");

  forn(i, n)
    lh.add(x[i]);
  forn(i, n)
    lh.extract_min();
  timeStamp("leftist heap: %.2f\n");

  forn(i, n)
    sh.add(x[i]);
  forn(i, n)
    sh.extract_min();
  timeStamp("skew heap: %.2f\n");

  forn(i, n)
    Blh.add(x[i]);
  forn(i, n)
    Blh.extract_min();
  timeStamp("boot strapping with leftist heap: %.2f\n");

  forn(i, n)
    Bsh.add(x[i]);
  forn(i, n)
    Bsh.extract_min();
  timeStamp("boot strapping with skew heap: %.2f\n");

  priority_queue<int, vector<int>, greater<int>> q;
  forn(i, n)
    q.push(x[i]);
  forn(i, n)
    q.pop();
  timeStamp("priority_queue: %.2f\n");

  multiset<int> s;
  forn(i, n)
    s.insert(x[i]);
  forn(i, n)
    s.erase(s.begin());
  timeStamp("set: %.2f\n");
}
