#ifndef SKEW_HEAP_H
#define SKEW_HEAP_H

#include <iostream>
#include <fstream>
#include <cassert>
#include <vector>
#include "mergeable_heap_node.h"

using namespace std;

template <class T>
struct skew_heap
{
  mergeable_heap_node<T>* root;
  mergeable_heap_node<T>* temp;
  mergeable_heap_node<T>* b;
  int N;
  skew_heap() {root = NULL; temp = NULL; b = NULL;}
  bool empty() {return root == NULL;}
  mergeable_heap_node<T>* merge(mergeable_heap_node<T>*, mergeable_heap_node<T>*);
  void selfmerge(mergeable_heap_node<T>*);
  T min();
  T extract_min();
  void add(T);
  void down(int v);
  void build(int, vector<T>);
  void print(mergeable_heap_node<T>*);
  void print() {cout << "leftist heap:\n"; print(root); cout << "\n\n";}
};

template <class T>
mergeable_heap_node<T>* skew_heap<T>::merge(mergeable_heap_node<T>* h1, mergeable_heap_node<T>* h2)
{
  if(h1 == NULL)
    return h2;
  if(h2 == NULL)
    return h1;
  if((h1 -> x) > (h2 -> x))
    swap(h1, h2);
  h1 -> r = merge(h1 -> r, h2);
  assert(h1 -> r != NULL);
  swap(h1 -> l, h1 -> r);
  assert(h1 != NULL);
  return h1;
}                                                                                                                  

template <class T>
void skew_heap<T>::selfmerge(mergeable_heap_node<T>* h2)
{
  root = merge(root, h2);
}

template <class T>
T skew_heap<T>::min()
{
  assert(root != NULL);
  return root -> x;          
}

template <class T>
T skew_heap<T>::extract_min()
{
  assert(root != NULL);
  T res = root -> x;          
  temp = merge(root -> l, root -> r);
  delete root;
  root = temp;  
  return res;  
}

template <class T>
void skew_heap<T>::add(T y)
{
  mergeable_heap_node<T>* nd = new mergeable_heap_node<T>;
  nd -> l = NULL;
  nd -> r = NULL;
  nd -> x = y;
  root = merge(root, nd);  
}

template <class T>
void skew_heap<T>::down(int v)
{
  int min_num = v;
  if(2 * v     <= N && b[2 * v - 1].x     < b[min_num - 1].x)
    min_num = 2 * v;
  if(2 * v + 1 <= N && b[2 * v + 1 - 1].x < b[min_num - 1].x)
    min_num = 2 * v + 1;
  if(min_num != v)
  {
    swap(b[min_num - 1].x, b[v - 1].x);
    down(min_num);
  }
}

template <class T>
void skew_heap<T>::build(int n, vector<T> a)
{
  N = n;
  int i;
  b = new mergeable_heap_node<T>[N];
  for(i = 1; i <= N; i++)
    b[i - 1].x = a[i - 1];
  for(i = N / 2; i >= 1; i--)
    down(i);
  for(i = N; i >= 1; i--)
  {
    if(2 * i <= N)
      b[i - 1].l = &b[2 * i - 1];
    if(2 * i + 1 <= N)
      b[i - 1].r = &b[2 * i + 1 - 1];
  }    
  root = b;
}

template <class T>
void skew_heap<T>::print(mergeable_heap_node<T>* nd)
{
  if(nd == NULL)
    printf("NULL\n");
  else
  {
    nd -> print();
    cout << endl;
    if(nd -> l != NULL)
      print(nd -> l);  
    if(nd -> r != NULL)
      print(nd -> r);
  }  
}

#endif // SKEW_HEAP_H















