#ifndef LEFTIST_HEAP_H
#define LEFTIST_HEAP_H

#include <iostream>
#include <fstream>
#include <vector>
#include <cassert>

using namespace std;

template <class T>
struct leftist_heap_node
{
  T x;
  leftist_heap_node<T>* l;
  leftist_heap_node<T>* r;
  int rank;
  leftist_heap_node<T>() { l = NULL; r = NULL; rank = 0; }
  void print()
  { 
    cout << "x=" << x;
    if(l != NULL)
      cout << " l->x=" << l -> x;
    if(r != NULL)
      cout << " r->x=" << r -> x;
    cout << " rank=" << rank; 
  }
};

template <class T>
struct leftist_heap
{
  leftist_heap_node<T>* root;
  leftist_heap_node<T>* temp;
  leftist_heap_node<T>* b;
  int N;
  leftist_heap() {root = NULL; temp = NULL; b = NULL; }
  bool empty() {return root == NULL;}
  leftist_heap_node<T>* merge(leftist_heap_node<T>*, leftist_heap_node<T>*);
  void selfmerge(leftist_heap_node<T>*);
  T min();
  T extract_min();
  void add(T);
  void down(int v);
  void build(int, vector<T>);
  void print(leftist_heap_node<T>*);
  void print() {cout << "leftist heap:\n"; print(root); cout << "\n\n";}
};

template <class T>
leftist_heap_node<T>* leftist_heap<T>::merge(leftist_heap_node<T>* h1, leftist_heap_node<T>* h2)
{
  if(h1 == NULL)
    return h2;
  if(h2 == NULL)
    return h1;
  if((h1 -> x) > (h2 -> x))
    swap(h1, h2);
  h1 -> r = merge(h1 -> r, h2);
  assert(h1 -> r != NULL);
  if(h1 -> l == NULL || (h1 -> r -> rank > h1 -> l -> rank))
    swap(h1 -> l, h1 -> r);
  assert(h1 != NULL);
  if(h1 -> r == NULL)
    h1 -> rank = 1;
  else
    h1 -> rank = h1 -> r -> rank + 1;
  return h1;
}                                                                                                                  

template <class T>
void leftist_heap<T>::selfmerge(leftist_heap_node<T>* h2)
{
  root = merge(root, h2);
}

template <class T>
T leftist_heap<T>::min()
{
  assert(root != NULL);
  return root -> x;          
}

template <class T>
T leftist_heap<T>::extract_min()
{
  assert(root != NULL);
  T res = root -> x;          
  temp = merge(root -> l, root -> r);
  delete root;
  root = temp;  
  return res;  
}

template <class T>
void leftist_heap<T>::add(T y)
{
  leftist_heap_node<T>* nd = new leftist_heap_node<T>;
  nd -> rank = 1;
  nd -> x = y;
  root = merge(root, nd);  
}

template <class T>
void leftist_heap<T>::down(int v)
{
  int min_num = v;
  if(2 * v <= N && b[2 * v - 1].x < b[min_num - 1].x)
    min_num = 2 * v;
  if(2 * v + 1 <= N && b[2 * v + 1 - 1].x < b[min_num - 1].x)
    min_num = 2 * v + 1;
  if(min_num != v)
  {
    swap(b[min_num - 1].x, b[v - 1].x);
    down(min_num);
  }
}

template <class T>
void leftist_heap<T>::build(int n, vector<T> a)
{
  N = n;
  int i, r;
  b = new leftist_heap_node<T>[N];
  for(i = 1; i <= N; i++)
    b[i - 1].x = a[i - 1];
  for(i = N / 2; i >= 1; i--)
    down(i);
  for(i = N; i >= 1; i--)
  {
    r = 0;
    if(2 * i <= N)
    {
      b[i - 1].l = &b[2 * i - 1];
      r = b[2 * i - 1].rank; 
    }
    if(2 * i + 1 <= N)
    {
      b[i - 1].r = &b[2 * i + 1 - 1];
      r = b[2 * i + 1 - 1].rank; 
    }
    b[i - 1].rank = r + 1;
  }    
  root = b;
}

template <class T>
void leftist_heap<T>::print(leftist_heap_node<T>* nd)
{
  if(nd == NULL)
    printf("NULL\n");
  else
  {
    nd -> print();
    cout << endl;
    if(nd -> l != NULL)
      print(nd -> l);  
    if(nd -> r != NULL)
      print(nd -> r);
  }  
}

#endif // LEFTIST_HEAP_H















