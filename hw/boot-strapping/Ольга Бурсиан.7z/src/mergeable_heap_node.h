#ifndef MERGEABLE_HEAP_NODE_H
#define MERGEABLE_HEAP_NODE_H

#include <iostream>
#include <fstream>
#include <cassert>

using namespace std;

template <class T>
struct mergeable_heap_node
{
  T x;
  mergeable_heap_node<T>* l;
  mergeable_heap_node<T>* r;
  mergeable_heap_node() { l = NULL; r = NULL; }
  void print()
  { 
    cout << "x=" << x;
    if(l != NULL)
      cout << " l->x=" << l -> x;
    if(r != NULL)
      cout << " r->x=" << r -> x;
  }
};

#endif // MERGEABLE_HEAP_NODE_H
