{-# LANGUAGE UnicodeSyntax #-}

import Control.DeepSeq (NFData)
import System.Random

import Data.Heap as H
import Data.Heap.Leftist
import Data.Heap.Skew
import Data.Heap.FastInsert
import Data.Heap.Bootstrap
import Measure
import Utils


measureMerge ∷ (NFData (h Int), MergeHeap h) ⇒ String → h Int → IO ()
measureMerge = measureHeap 1000 10000 "merge" buildAndMerge setupEnv
  where
    buildAndMerge = foldr merge
    setupEnv n = return $ map build $ take 2 $ randomLists (mkStdGen 2134) n

main = do
  measureMerge "skew" (empty ∷ SkewHeap Int)
  measureMerge "fi-skew" (empty ∷ FastInsert SkewHeap Int)
  measureMerge "bs-skew" (empty ∷ Bootstrap (FastInsert SkewHeap) Int)
