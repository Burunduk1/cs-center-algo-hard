{-# LANGUAGE UnicodeSyntax #-}

module Measure where

import Control.DeepSeq (NFData)
import Control.Exception
import Control.Monad.Trans (liftIO)
import Criterion.Internal (runAndAnalyse)
import Criterion.IO.Printf (writeCsv)
import Criterion.Main.Options (defaultConfig)
import Criterion.Measurement (initializeTime)
import Criterion.Monad (withConfig)
import Criterion.Types
import System.Directory (removeFile)
import System.IO.Error (isDoesNotExistError)

import Data.Heap


measureHeap ∷ (NFData b, MergeHeap h) ⇒ Int → Int → String → (h a → b → c) → (Int → IO b) → String → h a → IO ()
measureHeap step max reportName test setupEnv heapName heap = do
  let filename = "report-" ++ reportName ++ "-" ++ heapName
      config = defaultConfig { timeLimit = 5
                             , csvFile = Just filename
                             }
  removeFile filename `catch` handleExists
  let bsgroup = bgroup "" (map createBenchmark [0, step .. max])
  withConfig config $ do
    writeCsv ("Name","Mean","MeanLB","MeanUB","Stddev","StddevLB", "StddevUB")
    liftIO initializeTime
    runAndAnalyse (const True) bsgroup
    where
      createBenchmark n = env (setupEnv n) $ \e → bench (show n) $ whnf (test heap) e
      handleExists e | isDoesNotExistError e = return ()
                     | otherwise             = throwIO e
