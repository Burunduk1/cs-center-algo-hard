{-# LANGUAGE UnicodeSyntax #-}

import Control.Monad
import System.Random

import Data.Heap as H
import Data.Heap.Leftist
import Data.Heap.Skew
import Data.Heap.FastInsert
import Data.Heap.Bootstrap
import Utils


----------------------------------------------------------
type SuperHeap =
                 {-- LeftistHeap --}
                 {-- SkewHeap --}
                 {-- FastInsert LeftistHeap --}
                 {-- FastInsert SkewHeap --}
                 {--} Bootstrap (FastInsert LeftistHeap) --}
                 {-- Bootstrap (FastInsert SkewHeap) --}
runs ∷ Int
runs = 1000

listSize ∷ Int
listSize = 100
----------------------------------------------------------


runTests ∷ MergeHeap h ⇒ Int → Int → h Int → IO ()
runTests count len heap = do
  putStrLn $ "Running test for " ++ show count ++ " times with list length " ++ show len ++ "."

  forM_ [1..count] $ \i → do
--    seed ← newStdGen
    let seed = mkStdGen 42
    when (i `mod` 10 == 1) (putStrLn $ "Test #" ++ show i ++ "...")
    unless (testHeap len seed heap) (error $ "FAILED: #" ++ show i ++ ".")


main = runTests runs listSize (empty ∷ SuperHeap Int)
