{-# LANGUAGE UnicodeSyntax #-}

module Utils where

import Data.List
import System.Random

import Data.Heap as H


sortWithHeap ∷ MergeHeap h ⇒ h Int → [Int] → [Int]
sortWithHeap heap = unfoldr extractMin . foldr H.insert heap

testWithList ∷ MergeHeap h ⇒ [Int] → h Int → Bool
testWithList xs heap =  sort xs == sortWithHeap heap xs

testHeap ∷ MergeHeap h ⇒ Int → StdGen → h Int → Bool
testHeap n = testWithList . take n . randomList

randomList ∷ StdGen → [Int]
randomList = unfoldr (Just . random)

randomLists ∷ StdGen → Int → [[Int]]
randomLists g n = chop n $ randomList g
  where
    chop n xs = let (l, rest) = splitAt n xs
                in l : chop n rest
