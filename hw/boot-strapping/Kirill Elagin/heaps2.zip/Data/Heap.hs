{-# LANGUAGE UnicodeSyntax #-}

module Data.Heap where


class MergeHeap h where
  empty ∷ h t

  singleton ∷ Ord t ⇒ t → h t
  singleton v = insert v empty

  insert ∷ Ord t ⇒ t → h t → h t
  insert v h = merge h (singleton v)

  getMin ∷ Ord t ⇒ h t → Maybe t

  extractMin ∷ Ord t ⇒ h t → Maybe (t, h t)

  merge ∷ Ord t ⇒ h t → h t → h t

  mergeList ∷ Ord t ⇒ [h t] → h t
  mergeList [] = empty
  mergeList [h] = h
  mergeList hs = mergeList (mergePairs hs)
    where
      mergePairs ∷ (MergeHeap h, Ord t) ⇒ [h t] → [h t]
      mergePairs (x : y : zs) = merge x y : mergePairs zs
      mergePairs zs = zs

  build ∷ Ord t ⇒ [t] → h t
  build = mergeList . map singleton
