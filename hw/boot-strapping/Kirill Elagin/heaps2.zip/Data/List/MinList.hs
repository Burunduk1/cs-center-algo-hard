{-# LANGUAGE UnicodeSyntax #-}

module Data.List.MinList (MinList(..), empty, singleton, insert, toList, Data.List.MinList.min) where


newtype MinList t = MinList ([t], Maybe t)

empty ∷ MinList t
empty = MinList ([], Nothing)

singleton ∷ t → MinList t
singleton v = MinList ([v], Just v)

insert ∷ Ord t ⇒ t → MinList t → MinList t
insert v (MinList (vs, m)) = MinList (v : vs, case m of Nothing → Just v
                                                        Just m' → Just $ Prelude.min v m')

min ∷ MinList t → Maybe t
min (MinList (_, m)) = m

toList ∷ MinList t → [t]
toList (MinList (vs, _)) = vs
