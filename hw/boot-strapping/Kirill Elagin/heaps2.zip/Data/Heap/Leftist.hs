{-# LANGUAGE UnicodeSyntax #-}

module Data.Heap.Leftist (LeftistHeap) where

import Data.Heap


data LeftistHeap t = Fork t !(LeftistHeap t) !(LeftistHeap t) {-# UNPACK #-} !Int | Null

instance MergeHeap LeftistHeap where
  empty = Null

  singleton v = Fork v Null Null 1

  getMin Null = Nothing
  getMin (Fork v _ _ _) = Just v

  extractMin Null = Nothing
  extractMin (Fork v l r _) = Just (v, merge l r)

  merge Null h = h
  merge h Null = h
  merge h1@(Fork v1 _ _ _) h2@(Fork v2 _ _ _) | v1 > v2 = merge h2 h1
  merge (Fork v1 l1 r1 _) h2 = let m = merge r1 h2
                                   (l', r') = if rank l1 <= rank m then (l1, m) else (m, l1)
                                   s' = rank r' + 1
                               in Fork v1 l' r' s'


rank ∷ LeftistHeap t → Int
rank Null = 0
rank (Fork _ _ _ s) = s
