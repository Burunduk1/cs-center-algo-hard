{-# LANGUAGE FlexibleContexts, UnicodeSyntax #-}

module Data.Heap.FastInsert (FastInsert) where

import Control.DeepSeq (NFData, rnf)
import Control.Monad

import Data.Heap
import qualified Data.List.MinList as ML


data FastInsert h t = FastInsert !(h t) !(ML.MinList t)

instance MergeHeap h ⇒ MergeHeap (FastInsert h) where
  empty = fixed empty

  singleton v = FastInsert (singleton v) (ML.singleton v)

  insert v (FastInsert h l) = FastInsert h (ML.insert v l)

  getMin (FastInsert h l) = let a = getMin h
                             in case ML.min l of Nothing → a
                                                 Just b → liftM (min b) a

  extractMin h = do (m, h') ← extractMin (fix h)
                    return (m, fixed h')

  merge h1 h2 = fixed (fix h1 `merge` fix h2)


fix ∷ (MergeHeap h, Ord t) ⇒ FastInsert h t → h t
fix (FastInsert h l) = merge h (build . ML.toList $ l)

fixed ∷ MergeHeap h ⇒ h t → FastInsert h t
fixed h = FastInsert h ML.empty


instance NFData (h t) ⇒ NFData (FastInsert h t) where
  rnf (FastInsert h _) = rnf h `seq` ()
