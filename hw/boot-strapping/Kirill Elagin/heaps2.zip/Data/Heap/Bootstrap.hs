{-# LANGUAGE FlexibleContexts, UndecidableInstances, UnicodeSyntax #-}

module Data.Heap.Bootstrap (Bootstrap) where

import Control.DeepSeq (NFData, rnf)

import Data.Heap


data Bootstrap h t = BsFork !(h (Bootstrap h t)) t | BsNull

instance Eq t ⇒ Eq (Bootstrap h t) where
  BsNull           == BsNull           = True
  (BsFork _ m1) == (BsFork _ m2) = m1 == m2
  _                == _                = False

instance Ord t ⇒ Ord (Bootstrap h t) where
  compare BsNull BsNull                     = EQ
  compare BsNull _                          = LT
  compare _ BsNull                          = GT
  compare (BsFork _ m1) (BsFork _ m2) = compare m1 m2

instance MergeHeap h ⇒ MergeHeap (Bootstrap h) where
  empty = BsNull

  singleton = BsFork empty

  getMin BsNull = Nothing
  getMin (BsFork _ m) = Just m

  extractMin BsNull = Nothing
  extractMin (BsFork h m) = Just $ case extractMin h of Nothing → (m, BsNull)
                                                        Just (BsNull, _)          → error "Bootstrap.extractMin: impossible happened"
                                                        Just (BsFork h'' m'', h') → (m, BsFork (merge h' h'') m'')

  merge BsNull b = b
  merge b BsNull = b
  merge b1@(BsFork _ m1) b2@(BsFork _ m2) | m1 > m2 = merge b2 b1
  merge (BsFork h1 m1) b2 = BsFork (insert b2 h1) m1


instance (NFData t, NFData (h (Bootstrap h t))) ⇒ NFData (Bootstrap h t) where
  rnf BsNull = ()
  rnf (BsFork h t) = rnf h `seq` rnf t
