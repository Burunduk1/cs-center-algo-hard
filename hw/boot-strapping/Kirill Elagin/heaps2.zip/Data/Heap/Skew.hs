{-# LANGUAGE UnicodeSyntax #-}

module Data.Heap.Skew (SkewHeap) where

import Control.DeepSeq (NFData, rnf)

import Data.Heap


data SkewHeap t = Fork t !(SkewHeap t) !(SkewHeap t) | Null

instance MergeHeap SkewHeap where
  empty = Null

  singleton v = Fork v Null Null

  getMin Null = Nothing
  getMin (Fork v _ _) = Just v

  extractMin Null = Nothing
  extractMin (Fork v l r) = Just (v, merge l r)

  merge Null h = h
  merge h Null = h
  merge h1@(Fork v1 _ _) h2@(Fork v2 _ _) | v1 > v2 = merge h2 h1
  merge (Fork v1 l1 r1) h2 = Fork v1 (merge r1 h2) l1


instance NFData t ⇒ NFData (SkewHeap t) where
  rnf Null = ()
  rnf (Fork t l r) = rnf t `seq` rnf l `seq` rnf r
