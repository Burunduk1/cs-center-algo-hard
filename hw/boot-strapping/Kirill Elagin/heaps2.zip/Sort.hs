{-# LANGUAGE UnicodeSyntax #-}

import System.Random

import Data.Heap as H
import Data.Heap.Leftist
import Data.Heap.Skew
import Data.Heap.FastInsert
import Data.Heap.Bootstrap
import Measure
import Utils


measureSort ∷ MergeHeap h ⇒ String → h Int → IO ()
measureSort = measureHeap 1000 10000 "sort" sortWithHeap (\n → return $ take n $ randomList (mkStdGen 2134))

main = do
  measureSort "leftist" (empty ∷ LeftistHeap Int)
  measureSort "skew" (empty ∷ SkewHeap Int)
  measureSort "fi-leftist" (empty ∷ FastInsert LeftistHeap Int)
  measureSort "fi-skew" (empty ∷ FastInsert SkewHeap Int)
  measureSort "bs-leftist" (empty ∷ Bootstrap (FastInsert LeftistHeap) Int)
  measureSort "bs-skew" (empty ∷ Bootstrap (FastInsert SkewHeap) Int)
